/*
    TextShadow/BoxShadow
    Called from the editMenu.

    createMenu()
    type: text-shadow || box-shadow
    count: how many buttons
    names: names of buttons
    id: selected element id
    Called From: editmenu.js for shadow and boxShadow
*/
menu.externalShadowMenu = {
    menuID: "externalMenu",
    menu: function (){
        var menu = document.createElement('div');
            menu.id = this.menuID;
            document.body.appendChild(menu);
            $(menu).draggable({axis: 'y'});
        return menu;
    },
    colorButton: function(){
        var button = document.createElement('div');
            button.className = 'exColorButton';
            button.innerHTML = 'Color';
            button.onclick = function () {
                action.cgShadowColor('#' + menu.externalShadowMenu.menuID);
            };
        return button;
    },
    valueButton: function (incrementID, type, symbol, classes){
        var button = document.createElement('div');
            button.innerHTML = symbol;
            button.className = classes;
            button.title = incrementID;
            button.onclick = function () {
                menu.externalShadowMenu.handleChange($(this), type);
            };
        return button;
    },
    buttonLabel: function(name, classes){
        var label = document.createElement('div');
            label.innerHTML = name;
            label.className = classes;
        return label;
    },
    buttonInput: function (currentValue, classes){
        var input = document.createElement('input');
            input.value = currentValue;
            input.className = classes;
        return input;
    },
    currentValue: function (type){
        var result = $('#' + action.selectedItem).css(type).match(/(-?\d+px)|(rgb\(.+\))/g);
            if(!result){
                result = ['rgb(0,0,0)', '0px', '0px', '0px'];
            }
        return result;
    },
    createMenu: function (type, count, names, id) {
        var menu = this.menu(),
            externalInputContainer,
            i;
        for (i = 0; i < count; i++) {
            externalInputContainer = document.createElement('div'),
            externalInputContainer.className = 'exInput' + i;
            externalInputContainer.appendChild(this.buttonInput(parseInt(this.currentValue(type)[i + 1], 10), 'exInput'));
            externalInputContainer.appendChild(this.valueButton(i, type, '+', 'exInc exButton'));
            externalInputContainer.appendChild(this.valueButton(i, type, '-', 'exDec exButton'));
            externalInputContainer.appendChild(this.buttonLabel(names[i], 'exTopLabel'));
            menu.appendChild(externalInputContainer);
        };
        menu.appendChild(this.colorButton());
    },
    handleChange: function (button, type) {
        //returns 0, 1, 2 (0 for x, 1 for y, 2 for blur);
        var title = button.context.title,
            position,
            result = $('#' + action.selectedItem).css(type).match(/(-?\d+px)|(rgb\(.+\))/g),
            color, y, x, blur, oldValue, newVal;

        if (result) {
            color = result[0];
            y = result[1];
            x = result[2];
            blur = result[3];
        } else {
            color = 'rgb(0,0,0)';
            y = '0px';
            x = '0px';
            blur = '0px';
        }

        oldValue = button.parent().find("input").val();
        if (button.text() === "+") {
            newVal = parseFloat(oldValue) + 1;
        } else if(button.text() === "-"){
            if (oldValue > 0) {
                newVal = parseFloat(oldValue) - 1;
            } else {
                newVal = 0;
            }
        } else {
            newVal = 0;
        }
        button.parent().find("input").val(newVal);

        switch (title) {
        case '0':
            y = newVal + 'px';
            break;
        case '1':
            x = newVal + 'px';
            break;
        case '2':
            blur = newVal + 'px';
            break;
        }
        newVal = y + ' ' + x + ' ' + blur + ' ' + color;
        action.setCss(action.selectedItem, type, newVal);
    },
    removeMenu: function () {
        $('#' + this.menuID).remove();
    }
};
