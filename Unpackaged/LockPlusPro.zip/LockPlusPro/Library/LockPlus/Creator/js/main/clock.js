//var lang = (window.navigator.language.length >= 2) ? window.navigator.language.split('-')[0] : 'en';

var lang = 'en';
var celsius = false;

function checkDiv(div) {
    'use strict';
    if (document.getElementById(div)) {
        return document.getElementById(div);
    }
    return;
}

function getAffix(div, type) {
    var affix = div.getAttribute('data-' + type);
    affix = affix === null ? '' : affix;
    return affix;
}

var translate = {
    en: {
        weekday: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
        sday: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
        mday: ["Sun", "Mon", "Tues", "Wednes", "Thurs", "Fri", "Sat"],
        month: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
        smonth: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
        condition: ["Tornado", "Tropical Storm", "Hurricane", "Thunderstorm", "Thunderstorm", "Snow", "Sleet", "Sleet", "Freezing Drizzle", "Drizzle", "Freezing Rain", "Showers", "Showers", "Flurries", "Snow", "Snow", "Snow", "Hail", "Sleet", "Dust", "Fog", "Haze", "Smoky", "Blustery", "Windy", "Cold", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Cloudy", "Clear", "Sunny", "Fair", "Fair", "Sleet", "Hot", "Thunderstorms", "Thunderstorms", "Thunderstorms", "Showers", "Heavy Snow", "Light Snow", "Heavy Snow", "Partly Cloudy", "Thunderstorm", "Snow", "Thunderstorm", "blank"]
    },
    ru: {
        weekday: ["Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"],
        sday: ["Вос", "Пон", "Вто", "Сре", "Чет", "Пят", "Суб"],
        mday: ["Sun", "Mon", "Tues", "Wednes", "Thurs", "Fri", "Sat"],
        month: ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"],
        smonth: ["Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"],
        condition: ["Торнадо", "Тропический шторм", "Ураган", "Гроза", "Гроза", "Снег", "Мокрый снег", "Мокрый снег", "Изморозь", "Морось", "Ледяной дождь", "Ливень", "Ливень", "Сильные порывы ветра", "Снег", "Снег", "Снег", "Град", "Мокрый снег", "Пыль", "Туман", "Легкий туман", "Туманно", "Порывисто", "Ветренно", "Холодно", "Облачно", "Облачно", "Облачно", "Облачно", "Облачно", "Ясно", "Солнечно", "Ясно", "Ясно", "Мокрый снег", "Жарко", "Гроза", "Гроза", "Гроза", "Ливень", "Снегопад", "Небольшой снег", "Снегопад", "Переменная облачность", "Гроза", "Снег", "Гроза", "пусто"]
    },
    cz: {
        weekday: ["Neděle", "Pondělí", "Úterý", "Středa", "Čtvrtek", "Pátek", "Sobota"],
        sday: ["Ne", "Po", "Út", "St", "Čt", "Pá", "So"],
        mday: ["Sun", "Mon", "Tues", "Wednes", "Thurs", "Fri", "Sat"],
        month: ["Leden", "Únor", "Březen", "Duben", "Květen", "Červen", "Červenec", "Srpen", "Září", "Říjen", "Listopad", "Prosinec"],
        smonth: ["Led", "Úno", "Bře", "Dub", "Kvě", "Čen", "Čec", "Srp", "Zář", "Říj", "Lis", "Pro"],
        condition: ["Tornádo", "Tropická bouře", "Hurikán", "Bouře", "Bouře", "Sněžení", "Déšť a sníh", "Déšť a sníh", "Mrznoucí mrholení", "Mrholení", "Mrznoucí déšť", "Přeháňky", "Přeháňky", "Poryvy větru", "Sněžení", "Sněžení", "Sněžení", "Kroupy", "Déšť a sníh", "Prach", "Mlhy", "Řídké mlhy", "Kouř", "Větrno s bouřkami", "Větrno", "Chladno", "Oblačno", "Oblačno", "Oblačno", "Oblačno", "Oblačno", "Jasno", "Slunečno", "Krásně", "Krásně", "Déšť a sníh", "Horko", "Bouře", "Bouře", "Bouře", "Přeháňky", "Husté sněžení", "Lehké sněžení", "Husté sněžení", "Polojasno", "Bouře", "Sněžení", "Bouře", "prázdné"]
    },
    it: {
        weekday: ['Domenica', 'Luned&#236', 'Marted&#236', 'Mercoled&#236', 'Gioved&#236', 'Venerd&#236', 'Sabato'],
        sday: ["Sun", "Mon", "Mar", "Mer", "Gio", "Ven", "Sat"],
        mday: ["Sun", "Mon", "Tues", "Wednes", "Thurs", "Fri", "Sat"],
        month: ["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"],
        smonth: ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"],
        condition: ["Tornado", "Tempesta Tropicale", "Uragano", "Temporali Forti", "Temporali", "Pioggia mista a Neve", "Nevischio", "Nevischio", "Pioggia Gelata", "Pioggerella", "Pioggia Ghiacciata", "Pioggia", "Pioggia", "Neve a Raffiche", "Neve Leggera", "Tempesta di Neve", "Neve", "Grandine", "Nevischio", "Irregolare", "Nebbia", "Foschia", "Fumoso", "Raffiche di Vento", "Ventoso", "Freddo", "Nuvoloso", "Molto Nuvoloso", "Molto Nuvoloso", "Nuvoloso", "Nuvoloso", "Sereno", "Sereno", "Bel Tempo", "Bel Tempo", "Pioggia e Grandine", "Caldo", "Temporali Isolati", "Temporali Sparsi", "Temporali Sparsi", "Rovesci Sparsi", "Neve Forte", "Nevicate Sparse", "Neve Forte", "Nuvoloso", "Rovesci Temporaleschi", "Rovesci di Neve", "Temporali isolati", "Non Disponibile"]
    },
    sp: {
        weekday: ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"],
        sday: ["Sol", "Mon", "Mar", "Mie", "Jue", "Vie", "Sat"],
        mday: ["Sun", "Mon", "Tues", "Wednes", "Thurs", "Fri", "Sat"],
        month: ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"],
        smonth: ["Ene", "Feb", "Mar", "Abr", "Mayo", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dic"],
        condition: ["Tornado", "Tormenta Tropical", "Huracan", "Tormentas Electricas Severas", "Tormentas Electricas", "Mezcla de Lluvia y Nieve", "Mezcla de lluvia y aguanieve", "Mezcla de nieve y aguaniev", "Llovizna helada", "Llovizna", "Lluvia bajo cero", "Chubascos", "Chubascos", "Rafagas de nieve", "Ligeras precipitaciones de nieve", "Viento y nieve", "Nieve", "Granizo", "Aguanieve", "Polvareda", "Neblina", "Bruma", "Humeado", "Tempestuoso", "Vientoso", "Frio", "Nublado ", "Mayormente nublado", "Mayormente nublado", "despejado", "despejado", "Despejado", "Soleado", "Lindo", "Lindo", "Mezcla de lluvia y granizo", "Caluroso", "Tormentas electricas aisladas", "Tormentas electricas dispersas", "Tormentas electricas dispersas", "Chubascos dispersos", "Nieve fuerte", "Precipitaciones de nieve dispersas", "Nieve fuerte", "despejado", "Lluvia con truenos y relampagos", "Precipitaciones de nieve", "Tormentas aisladas", "No disponible"]
    },
    de: {
        weekday: ["Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag"],
        sday: ["Son", "Mon", "Die", "Mit", "Don", "Fre", "Sam"],
        mday: ["Sun", "Mon", "Tues", "Wednes", "Thurs", "Fri", "Sat"],
        month: ["Januar", "Februar", "März", "April", "Mai", "Juni", "Ju li", "August", "September", "Oktober", "November", "Dez ember"],
        smonth: ["Jan", "Feb", "Mä", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez "],
        condition: ["Tornado", "Tropischer Sturm", "Wirbelsturm", "Schwere Gewitter", "Gewitter", "Regen und Schnee", "Graupelschauer", "Schneeregen", "Gefrierender Nieselregen", "Nieselregen", "Gefrierender Regen", "Schauer", "Schauer", "Schneegestöber", "Leichte Schneeschauer", "Schneetreiben", "Schnee", "Hagel", "Schneeregen", "Staubig", "Nebelig", "Dunstschleier", "Dunstig", "Stürmisch", "Windig", "Kalt", "Bewölkt", "Meist Bewölkt", "Meist Bewölkt", "Bewölkt", "Bewölkt", "Klar", "Sonnig", "Heiter", "Heiter", "Regen und Hagel", "Heiss", "Örtliche Gewitter", "Vereinzelte Gewitter", "Vereinzelte Gewitter", "Vereinzelte Schauer", "Starker Schneefall", "Vereinzelte Schneeschauer", "Starker Schneefall", "Bewölkt", "Gewitter", "Scheeschauer", "Örtliche Gewitterschauer", "Nicht Verfügbar"]
    },
    fr: {
        weekday: ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"],
        sday: ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"],
        mday: ["Sun", "Mon", "Tues", "Wednes", "Thurs", "Fri", "Sat"],
        month: ["Janvie", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre"],
        smonth: ["Jan", "Fév", "Mar", "Avr", "Mai", "Jui", "Jui", "Aoû", "Sep", "Oct", "Nov", "Déc"],
        condition: ["Tornade", "Tropical", "Ouragan", "Orages Violents", "Orages", "Pluie", "Pluie", "Neige", "Bruine", "Bruine", "Pluie", "Averses", "Averses", "Quelques Flocons", "Faibles Chutes de Neige", "Rafales de Neige", "Neige", "GrÃªle", "Neige Fondue", "PoussiÃ©reux", "Brouillard", "Brume", "Brumeux", "TempÃªte", "Vent", "Temps Froid", "Temps Nuageux ", "TrÃ¨s Nuageux", "TrÃ¨s Nuageux", "Nuageux", "Nuageux", "Temps Clair", "Ensoleille", "Beau Temps", "Beau Temps", "Pluie et GrÃªles", "Temps Chaud", "Orages IsolÃ©s", "Orages Eparses", "Orages Eparses", "Averses Eparses", "Fortes Chutes de Neige", "Chutes de Neige Eparses", "Fortes Chutes de Neige", "Nuageux", "Orages", "Chute de Neige", "Orages IsolÃ©s", "Non Disponible"]
    },
    zh: {
        weekday: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'],
        sday: ['周日', '周一', '周二', '周三', '周四', '周五', '周六'],
        mday: ["Sun", "Mon", "Tues", "Wednes", "Thurs", "Fri", "Sat"],
        month: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'],
        smonth: ['一', '二', '三', '四', '五', '六', '七', '八', '九', '十', '十一', '十二'],
        condition: ["龙卷风", "热带风暴", "飓风", "雷暴", "雷暴", "雪", "雨雪", "雨雪", "冻毛毛雨", "细雨", "冻雨", "淋浴", "淋浴", "飘雪", "雪", "雪", "雪", "Hail", "雨雪", "尘", "牙齿", "阴霾", "烟", "风起云涌", "有风", "冷", "多云", "多云", "多云", "多云", "多云", "明确", "晴朗", "公平", "公平", "雨雪", "Hot", "雷暴", "雷暴", "雷暴", "淋浴", "大雪", "小雪", "大雪", "半 多云", "雷暴", "雪", "雷暴", "空白"]
    }
};

function clock(options) {
    'use strict';
    var getTimes = function () {
            var d = new Date(),
                funcs = {
                    daysInMonth: [31,0,31,30,31,30,31,31,30,31,30,31],
                    hour: function () {
                        var hour = (options.twentyfour === true) ? d.getHours() : (d.getHours() + 11) % 12 + 1;
                        return hour;
                    },
                    zhour : function () {
                        var hour = (options.twentyfour === true) ? d.getHours() : (d.getHours() + 11) % 12 + 1;
                        hour = hour < 10 ? "0" + hour : " " + hour;
                        return hour;
                    },
                    rawhour: function () {
                        return d.getHours();
                    },
                    minute: function () {
                        return (d.getMinutes() < 10) ? "0" + d.getMinutes() : d.getMinutes();
                    },
                    second: function () {
                        return (d.getSeconds() < 10) ? "0" + d.getSeconds() : d.getSeconds();
                    },
                    rawminute: function () {
                        return d.getMinutes();
                    },
                    ampmstrict: function(){
                        return (d.getHours() > 11) ? "pm" : "am";
                    },
                    am: function () {
                        return (d.getHours() > 11) ? "pm" : "am";
                    },
                    amalways: function(){
                        return (d.getHours() > 11) ? "pm" : "am";
                    },
                    tod: function () {
                        return (d.getHours() > 11) ? "Afternoon" : "Morning";
                    },
                    date: function () {
                        return d.getDate();
                    },
                    paddeddate: function () {
                        return (d.getDate() <= 9) ? "0" + d.getDate() : d.getDate();
                    },
                    prevdate: function () {
                        var pd = (this.date() === 0) ? this.daysInMonth[this.month() - 1] : this.date() - 1;
                        return pd;
                    },
                    nextdate: function () {
                        var nd = (this.date() === 0) ? this.daysInMonth[this.month() + 1] : this.date() + 1;
                        return nd;
                    },
                    day: function () {
                        return d.getDay();
                    },
                    month: function () {
                        return d.getMonth();
                    },
                    year: function () {
                        return d.getFullYear();
                    },
                    smyear: function () {
                        return d.getFullYear() % 1000;
                    },
                    hourtext: function () {
                        var hourtxt = (options.twentyfour === true) ? ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen", "Twenty", "Twenty One", "Twenty Two", "Twenty Three", "Twenty Four"] : ["Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve"];
                        return hourtxt[this.rawhour()];
                    },
                    minuteonetext: function () {
                        var minuteone = ["o' clock", "o' one", "o' two", "o' three", "o' four", "o' five", "o' six", "o' seven", "o' eight", "o' nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "Sixteen", "Seventeen", "eighteen", "Nineteen", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty"];
                        if (minuteone[this.rawminute()] !== undefined) {
                            return minuteone[this.rawminute()];
                        }
                        return "";
                    },
                    minuteonetextdot: function () {
                        var minuteone = ["", "one", "o.two", "o.three", "o.four", "o.five", "o.six", "o.seven", "o.eight", "o.nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "Sixteen", "Seventeen", "eighteen", "Nineteen", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Twenty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Thirty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Forty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty", "Fifty"];
                        if (minuteone[this.rawminute()] !== undefined) {
                            return minuteone[this.rawminute()];
                        }
                        return "";
                    },
                    minutetwotext: function () {
                        var minutetwo = ["", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", ""];
                        if (minutetwo[this.rawminute()] !== undefined) {
                            return minutetwo[this.rawminute()];
                        }
                        return "";
                    },
                    daytext: function () {
                        return translate[lang].weekday[this.day()];
                    },
                    yesterdaydaytext: function () {
                        return (this.day() === 0) ? translate[lang].weekday[6] : translate[lang].weekday[this.day() - 1];
                    },
                    nextdaytext: function () {
                        return (this.day() === 6) ? translate[lang].weekday[0] : translate[lang].weekday[this.day() + 1];
                    },
                    sdaytext: function () {
                        return translate[lang].sday[this.day()];
                    },
                    mdaytext: function () {
                        return translate[lang].mday[this.day()];
                    },
                    snextday: function () {
                        return (this.day() === 6) ? translate[lang].sday[0] : translate[lang].sday[this.day() + 1];
                    },
                    sprevday: function () {
                        return (this.day() === 0) ? translate[lang].sday[6] : translate[lang].sday[this.day() - 1];
                    },
                    monthtext: function () {
                        return translate[lang].month[this.month()];
                    },
                    nextmonthtext: function () {
                        return (this.month() === 11) ? translate[lang].month[0] : translate[lang].month[this.month() + 1];
                    },
                    prevmonthtext: function () {
                        return (this.month() === 0) ? translate[lang].month[11] : translate[lang].month[this.month() - 1];
                    },
                    smonthtext: function () {
                        return translate[lang].smonth[this.month()];
                    },
                    snextmonth: function () {
                        return (this.month() === 11) ? translate[lang].smonth[0] : translate[lang].smonth[this.month() + 1];
                    },
                    sprevmonth: function () {
                        return (this.month() === 0) ? translate[lang].smonth[11] : translate[lang].smonth[this.month() - 1];
                    },
                    datetext: function () {
                        var textdate = ["First", "Second", "Third", "Fourth", "Fifth", "Sixth", "Seventh", "Eighth", "Ninth", "Tenth", "Eleventh", "Twelfth", "Thirteenth", "Fourteenth", "Fifteenth", "Sixteenth", "Seventeenth", "Eightheenth", "Nineteenth", "Twentyith", "TwentyFirst", "TwentySecond", "TwentyThird", 'TwentyFourth', "TwentyFifth", "TwentySixth", "TwentySeventh", "TwentyEight", "TwentyNinth", "Thirtyith", "ThirtyFirst"];
                        return textdate[this.date() - 1];
                    },
                    nth: function (d) {
                        if (d > 3 && d < 21) {
                            return 'th';
                        }
                        switch (d % 10) {
                        case 1:
                            return "st";
                        case 2:
                            return "nd";
                        case 3:
                            return "rd";
                        default:
                            return "th";
                        }
                    },
                    dateplus: function () {
                        return this.date() + this.nth(Number(this.date()));
                    }
                };
            options.success(funcs);
            setTimeout(function () {
                getTimes();
            }, options.refresh);
        };
    getTimes();
}

function convertTOWord(num){
    var onesText = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'],
        tensText = ['', '', 'twenty', 'thirty', 'fourty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'],
        aboveText = ['', ' thousand ', ' million ', ' billion ', ' trillion ', ' quadrillion ', ' quintillion ', ' sextillion '],
        generatedArray = [],
        converted = '',
        i = 0;
        while(num){
            generatedArray.push( num % 1000 );
            num = parseInt( num / 1000, 10 );
        }
        while (generatedArray.length) {
            converted = (function( a ) {
                var x = Math.floor( a / 100 ),
                    y = Math.floor( a / 10 ) % 10,
                    z = a % 10;
                return ( x > 0 ? onesText[x] + ' hundred ' : '' ) +
                       ( y >= 2 ? tensText[y] + ' ' + onesText[z] : onesText[10*y + z] );
            })( generatedArray.shift() ) + aboveText[i++] + converted;
        }
        return converted;
}
//clock
function loadClock() {
    clock({
        twentyfour: false,
        refresh: 1000,
        success: function (clock) {
            'use strict';
            window.cF = clock;
            var clockElements = {
                datedotsmonth: clock.date() + '.' + clock.sdaytext(),
                datedotsmonthpad: clock.paddeddate() + '.' + clock.sdaytext(),
                smonthdotdate: clock.sdaytext() + '.' + clock.date(),
                smonthdotdatepad: clock.sdaytext() + '.' + clock.paddeddate(),
                monthnumslashdatepad: clock.month() + '/' + clock.paddeddate(),
                monthnumslashdate: clock.month() + '/' + clock.date(),
                dateslashmonthpad: clock.paddeddate() + '/' + clock.month(),
                dateslashmonth: clock.date() + '/' + clock.month(),
                dstring: clock.sdaytext() + ', ' + clock.smonthtext() + ' ' + clock.date(),
                dstringpad: clock.sdaytext() + ', ' + clock.smonthtext() + ' ' + clock.paddeddate(),
                daycut: clock.daytext().substring(3),
                smonthsplit: clock.monthtext().substring(3),
                timer: "00:00",
                lngclstring: "It's " + clock.hour() + ":" + clock.minute() + " on " + clock.daytext() + " the " + clock.dateplus(),
                clock: clock.hour() + ":" + clock.minute(),
                zclock: clock.zhour() + ":" + clock.minute(),

                clockdot: clock.hour() + "." + clock.minute(),
                zclockdot: clock.zhour() + "." + clock.minute(),

                clockline : clock.hour() + "|" + clock.minute(),
                clockpm : clock.hour() + ":" + clock.minute() + clock.am(),
                zhour: clock.zhour(),
                hour: clock.hour(),
                hrmin: clock.hourtext() + '.' + clock.minute(),
                hrmintx: (clock.minutetwotext() !== "") ? clock.hourtext() + '.' + clock.minuteonetextdot() +  '.' + clock.minutetwotext() : clock.hourtext() + '.' + clock.minuteonetextdot() + clock.minutetwotext(),
                minute: clock.minute(),
                second: clock.second(),
                pm: clock.am(),
                amalways: clock.amalways(),
                tod: clock.tod(),
                ttext: clock.hourtext() + " " + clock.minuteonetext() + ' ' + clock.minutetwotext(),
                htext: clock.hourtext(),
                mtext: clock.minuteonetext() + ' ' + clock.minutetwotext(),
                date: clock.date(),
                datepad: clock.paddeddate(),
                datepadfirst: String(clock.paddeddate()).charAt(0),
                datepadsecond: String(clock.paddeddate()).charAt(1),
                prevdate: clock.prevdate(),
                nextdate: clock.nextdate(),
                dateplus: clock.dateplus(),
                datetext: clock.datetext(),
                day: clock.daytext(),

                ttextstr: clock.hourtext() + "" + clock.minuteonetext() + '' + clock.minutetwotext() + '<span style="text-transform:uppercase">' + clock.daytext() + "</span>the" + clock.dateplus(),

                sclock: clock.hour() + ":" + clock.minute() + clock.ampmstrict(),
                sclockpadded: clock.zhour() + ":" + clock.minute() + clock.ampmstrict(),

                daydate: clock.daytext() + " " + clock.date(),
                datestringrev: clock.monthtext() + " " + clock.date() + ", " + clock.daytext(),
                nextday: clock.nextdaytext(),
                yestday: clock.yesterdaydaytext(),
                sday: clock.sdaytext(),
                mday: clock.mdaytext(),
                sday1: clock.sdaytext().slice(0,1),
                sday2: clock.sdaytext().slice(1,2),
                sday3: clock.sdaytext().slice(2,3),
                snextday: clock.snextday(),
                sprevday: clock.sprevday(),
                month: clock.monthtext(),
                nextmonth: clock.nextmonthtext(),
                prevmonth: clock.prevmonthtext(),
                monthstring: clock.monthtext() + " the " + clock.dateplus(),
                datedotmonth: clock.date() + '.' + clock.monthtext(),
                dateslashmonth : clock.date() + "/" + clock.monthtext(),
                datemonth : clock.date() + " " + clock.monthtext(),
                datemonthrev: clock.monthtext() + " " + clock.date(),
                smonth: clock.smonthtext(),
                smonth1: clock.smonthtext().slice(0,1),
                smonth2: clock.smonthtext().slice(1,2),
                smonth3: clock.smonthtext().slice(2,3),
                snextmonth: clock.snextmonth(),
                sprevmonth: clock.sprevmonth(),
                monthdot : clock.monthtext() + "." + clock.date(),
                monthdateyear : clock.monthtext() + " " + clock.date() + ", " + clock.year(),
                monthline : clock.monthtext() + "|" + clock.date() + "|" + clock.year(),
                monthlinespace : clock.monthtext() + " | " + clock.date() + " | " + clock.year(),
                mdy : (clock.month() + 1) + "/" + clock.date() + "/" + clock.year(),
                datestring : clock.daytext() + ", " + clock.monthtext() + " " + clock.date(),
                datespace : clock.daytext() + " " + clock.monthtext() + " " + clock.date(),
                datedash : clock.daytext() + "-" + clock.monthtext() + "-" + clock.date(),
                dateplusof : clock.dateplus() + " of " + clock.monthtext(),
                dateplusplusof : clock.daytext() + ", " + clock.dateplus() + " of " + clock.monthtext(),
                year: clock.year(),
                daydotdate: clock.daytext() + "." + clock.date(),
                daydatemonth: clock.daytext() + " | " + clock.date() + " " + clock.monthtext(),
                daydatesmonth: clock.daytext() + ' ' + clock.date() + ' ' + clock.smonthtext(),
                daydatescommamonth: clock.daytext() + ', ' + clock.date() + ' ' + clock.smonthtext(),
                yeartext: convertTOWord(clock.year()),
                yearnum: clock.year().toString().slice(2,4),
                clocksmush: clock.hour() + "" + clock.minute(),
                hrnsmin: clock.hourtext() + ' ' + clock.minute(),
                datebar: clock.month() + 1 + '|' + clock.date() + '|' + clock.smyear(),
                datesnslash: clock.month() + 1 + '/' + clock.date() + '/' + clock.smyear(),
                datesingled: clock.month() + 1  + '-' + clock.date() + '-' + clock.smyear(),
                hrsmush: clock.hourtext() + '' + clock.minute(),
                dayabdatemonth: clock.sdaytext() + ' ' + clock.date() + ' ' + clock.smonthtext(),
                daycommadatemonth: clock.sdaytext() + ', ' + clock.date() + ' ' + clock.smonthtext(),
                datemonthfirst: clock.date() + ' ' + clock.monthtext(),
                nsmd : clock.smonthtext() + " " + clock.date(),
                ndsm : clock.date() + " " + clock.smonthtext(),
                ndsmd : clock.date() + " " + clock.sdaytext(),
                nsmdd: clock.sdaytext() + " " + clock.date(),
                ndatedash: clock.daytext() + " - " + clock.monthtext() + " - " + clock.date(),
                nsmmyear: clock.smonthtext() + " " + clock.year(),
                nmdplusyear: clock.monthtext() + " " + clock.dateplus() + " " + clock.year(),
                nhrtmin: clock.hourtext() + ':' + clock.minute(),
                nhrtarrowmin: clock.hourtext() + '>>' + clock.minute(),
                nttext: "[" + clock.hourtext() + "]" + "" + clock.minuteonetext() + '' + clock.minutetwotext(),
                smdotdate: clock.smonthtext() + '.' + clock.date(),
                datesmdot: clock.date() + '.' + clock.smonthtext(),
                monthdayyear : clock.monthtext() + " " + clock.date() + " " + clock.year(),
                monthslashdate: clock.monthtext() + '/' + clock.date(),
                fullmonthdotdate: clock.monthtext() + '.' + clock.date(),
                datedotmonthfull: clock.date() + '.' + clock.monthtext(),
                datemonthyear: clock.date() + ' ' + clock.monthtext() + ', ' + clock.year(),
                prevdaystrings: clock.yesterdaydaytext() + ' ' + clock.monthtext() + ' ' + clock.prevdate(),
                todaystrings: clock.daytext() + ' ' + clock.monthtext() + ' ' + clock.date(),
                nextdaystrings: clock.nextdaytext() + ' ' + clock.monthtext() + ' ' + clock.nextdate()

            };
            Object.keys(clockElements).forEach(function (key) {
                var value = clockElements[key],
                    div = checkDiv(key);
                if (div) {
                    div.innerHTML = getAffix(div, 'prefix') + value + getAffix(div, 'suffix');
                }
            });
        }
    });
}
loadClock();
//endclock
var weatherdivs = function () {
    'use strict';
    var tcf = (celsius === true) ? 'c' : 'f',
        spd = (celsius === true) ? 'kph' : 'mph',
        weatherElements = {
            temp : '76',
            tempdeg : '76&deg;',
            tempdegplus : '76&degF',
            high : '80',
            highdeg : '80&deg',
            highdegplus : '80&degF',
            low : '70',
            lowdeg : '70&deg;',
            lowdegplus : '70&deg;F',
            highdashlow : '80-70',
            highslashlow : '80/70',
            highdashlowdeg : '80&deg;-70&deg;',
            highslashlowdeg : '80&deg;/70&deg;',
            lngwstring: "It's cloudy outside and the temp is around 35&deg;.",
            lngwstring2: "Currently it's 35&deg; outside.",
            lngwstring3: "Currently it's cloudy, the high today will reach 60&deg; </br> Right now it's 90&deg; and your battery is 50%",
            lngwstring4: "It could be cloudy and 50&deg; but who really knows. </br> What I can tell you is your battery is 50%:)",
            lngwstring5: "The current temperature is 90&deg;, it's cloudy with a wind speed of 30mph. </br> Your battery is at 90% and is charging.",
            city : 'Current City',
            condition : 'Cloudy',
            humidity : '60',
            windchill : '20&deg;',
            wind : '25mph',
            winddirection : 'N',
            visibility : '20miles',
            rain : '20%',
            dewpoint : '40&deg;',
            feelslike: '90',
            feelslikedeg: '90&deg;',
            sunrise: '5:00',
            sunset: '7:00',
            update: '7/11/15 8:05',
            icon: 'weather/real/simply.png',

            day1day: "Mon",
            day2day: "Tue",
            day3day: "Wed",
            day4day: "Thu",
            day5day: "Fri",

            day1lohigh: '75°/50°',
            day2lohigh: '75°/50°',
            day3lohigh: '75°/50°',
            day4lohigh: '75°/50°',
            day5lohigh: '75°/50°',

            day1icon: 'weather/real/simply.png',
            day2icon: 'weather/real/simply.png',
            day3icon: 'weather/real/simply.png',
            day4icon: 'weather/real/simply.png',
            day5icon: 'weather/real/simply.png',

            day1high: '75°',
            day2high: '75°',
            day3high: '75°',
            day4high: '75°',
            day5high: '75°',

            day1low: '50°',
            day2low: '50°',
            day3low: '50°',
            day4low: '50°',
            day5low: '50°',

            day1highno: '75',
            day2highno: '75',
            day3highno: '75',
            day4highno: '75',
            day5highno: '75',

            day1lowno: '50',
            day2lowno: '50',
            day3lowno: '50',
            day4lowno: '50',
            day5lowno: '50',

            tempcon: '76 Cloudy',
            tempcon1: '76°f Cloudy',
            tempcon2: '76° Cloudy',
            contemp: "Cloudy 76°",
            contemp2: "Cloudy 76°f",
            windstr: '25mph N'
    };
    Object.keys(weatherElements).forEach(function (key) {
        var value = weatherElements[key],
            div = checkDiv(key);
        if (div) {
            if (key === 'icon' || key === 'day1icon' || key === 'day2icon' || key === 'day3icon' || key === 'day4icon' || key === 'day5icon') {
                if (!document.getElementById(key).innerHTML.length > 0) {
                    var img = document.createElement('img');
                    img.id = 'iconImg' + key;
                    img.src = value;
                    img.className = 'icon';
                    img.style.width = action.savedElements.placedElements[key]['width'];
                    img.style.height = action.savedElements.placedElements[key]['height'];
                    div.appendChild(img);
                }
            } else {
                div.innerHTML = getAffix(div, 'prefix') + value + getAffix(div, 'suffix');
            }
        }
    });
};
weatherdivs();
//systemEl: ['name~Displays name of the phone', 'firmware~Current firmware', 'battery~Current battery', 'batterypercent~Current battery plus percent', 'unlock~text when tapped unlocks device'],
var systemdivs = function () {
    'use strict';
    var systemEl = {
        name: 'JunesiPhone', //[[UIDevice currentDevice] name];
        firmware: 'Version 8.3 (Build 12F70)', //[NSProcessInfo processInfo].operatingSystemVersionString;
        battery: '100', //Math.round([[UIDevice currentDevice]batteryLevel] * 100);
        batterypercent: '100%',
        chargingtxt: 'Not Charging',
        chargingstate: 'Charging',
        onlycharging: 'Charging',
        batteryperslashcharge: "80% / charging",
        ipaddress: "192.168.x.x",
        unlock: 'Unlock',
        respring: 'Respring',
        sleep: 'Sleep',
        flashlight: 'Flashlight',
        playmusic: 'r',
        nextmusic: 'y',
        prevmusic: 'x',
        playmusichide: 'r',
        nextmusichide: 'y',
        prevmusichide: 'x',
        songtitle: 'Song Title',
        songartist: 'Song Artist',
        songalbum: 'Song Album',
        songalbumArt: '',
        songtitlenohide: 'Song Title',
        songartistnohide: 'Song Artist',
        songalbumnohide: 'Song Album',
        songalbumArtnohide: '',
        searchicon: "z",
        searchtext: "Search",
        signal: "3",
        signalpercent: "40%",
        alarmstring: "Tue 10:30 AM",
        alarmstringsmall: "Tue 10:30",
        alarm24: "10:30 PM",
        alarm: "8:00",
        alarmhr: "8",
        alarmmin: "30",
        alarmday: "Tuesday",
        alarmsday: "Tue",
        wifi: "20",
        wifipercent: "20%",
        notifymail: "0",
        notifysms: "0",
        notifyphone: "0",
        notifywhats: "0",
        notifytelegram: "0",
        notifytelegramx: "0",
        notifyfacebook: "0",
        notifyfbmessenger: "0",
        notifydiscord: "0",
        notifyviber: "0",
        notifyinstagram: "0",
        notifygmail: "0",
        notifyoutlook: "0",
        notifyairmail: "0",
        notifyymail: "0",
        notifysnapchat: "0",
        notifyreddit: "0",
        notifygoogleplus: "0",
        notifylinkedin: "0",
        notifyslack: "0",
        notifyspark: "0",
        ramFree: "700",
        ramUsed: "100",
        ramAvailable: "800",
        ramFreeMB: "700mb",
        ramUsedMB: "100mb",
        ramAvailableMB: "800mb"
    };
    Object.keys(systemEl).forEach(function (key) {
        var value = systemEl[key],
            div = checkDiv(key);
        if (div) {
            div.innerHTML = getAffix(div, 'prefix') + value + getAffix(div, 'suffix');
        }
    });
};
systemdivs();

var miscDivs = function() {
    'use strict';
    var miscEl = {
        quote1: 'Sometimes when you innovate, you make mistakes. It is best to admit them quickly, and get on with improving your other innovations.',
        quote1Artist: 'Steve Jobs',
        textOne: 'Enter text',
        textTwo: 'Enter text',
        textThree: 'Enter text',
        textFour: 'Enter text',
        textFive: 'Enter text',
        textSix: 'Enter text',
        textSeven: 'Enter text',
        textEight: 'Enter text',
        textNine: 'Enter text',
        textTen: 'Enter text',
        textEleven: 'Enter text',
        textTwelve: 'Enter text',
        textThirteen: 'Enter text',
        textFourteen: 'Enter text',
        textFifteen: "Enter text",
        textSixteen: "Enter text",
        textSeventeen: "Enter text",
        textEighteen: "Enter text",
        textNineteen: "Enter text",
        textTwenty: "Enter text",
        textTwentyOne: "Enter text",
        boxOne: '',
        boxTwo: '',
        boxThree: '',
        boxFour: '',
        boxFive: '',
        boxCircleOne: '',
        boxCircleTwo: '',
        boxCircleThree: '',
        boxCircleFour: '',
        boxCircleFive: '',
        app1: 'Mail-com.apple.mobilemail',
        app2: 'SMS-com.apple.MobileSMS',
        app3: 'Phone-com.apple.mobilephone',
        app4: 'Twitter-com.atebits.Tweetie2',
        app5: 'Tweetbot3-com.tapbots.Tweetbot3',
        app6: 'Telegram-ph.telegra.Telegraph',
        app7: 'Instagram-com.burbn.instagram',
        app8: 'Pandora-com.pandora',
        app9: 'Spotify-com.spotify.client',
        app10: 'Facebook-com.facebook.Facebook',
        app11: 'Kik-com.kik.chat',
        app12: 'YouTube-com.google.ios.youtube',
        app13: 'WhatsApp-net.whatsapp.WhatsApp',
        app14: 'Safari-com.apple.mobilesafari',
        app15: 'Weather-com.apple.weather',
        app16: 'Clock-com.apple.mobiletimer',
        app17: 'Music-com.apple.Music',
        app18: 'Camera-com.apple.camera',
        app19: 'Reminders-com.apple.reminders',
        app20: 'Notes-com.apple.mobilenotes',
        app21: 'Maps-com.apple.Maps',
        app22: 'Calendar-com.apple.mobilecal',
        app23: 'Calculator-com.apple.calculator',
        app24: 'Cydia-com.saurik.Cydia',
        app25: 'YouTube-com.google.ios.youtube',
        app26: 'Settings-com.apple.Preferences',
        app27: 'AppStore-com.apple.AppStore',
        app28: 'Health-com.apple.Health',
        app29: 'TelegramHD-org.telegram.TelegramHD'
    };
    Object.keys(miscEl).forEach(function (key) {
        var value = miscEl[key],
            div = checkDiv(key);
        if(div && key.substring(0,3) === 'app'){
            div.innerHTML = value.split('-')[0];
            div.setAttribute('data-target',value.split('-')[1]);
        }else{
            if (div && div.innerHTML === '') {
                div.innerHTML = getAffix(div, 'prefix') + value + getAffix(div, 'suffix');
            }
        }
    });
}
miscDivs();
