action.moveall = function () {
    menu.toggle();
    var contain, input, divBtn, msg;

    contain = document.createElement('div');
    contain.id = "moveAllContainer";

    input = document.createElement("input");
    input.type = "text";
    input.className = "moveAllInput";
    input.id = "moveAllInput";
    contain.appendChild(input);

    divBtn = document.createElement('div');
    divBtn.className = "moveAllButton";
    divBtn.innerHTML = "Apply";
    divBtn.addEventListener('click', function () {
        var inputVal = document.getElementById('moveAllInput'),
            move;
        if (inputVal.value) {
            move = inputVal.value;
            Object.keys(action.savedElements.placedElements).forEach(function (key) {
                try {
                    if (action.savedElements.placedElements[key].top) {
                        var top = action.savedElements.placedElements[key].top;
                        action.savedElements.placedElements[key].top = parseInt(move, 10) + parseInt(top, 10);
                        document.getElementById(key).style.top = parseInt(move, 10) + parseInt(top, 10) + "px";
                    } else {
                        action.savedElements.placedElements[key].top = parseInt(move, 10);
                        document.getElementById(key).style.top = parseInt(move, 10) + "px";
                    }
                } catch (err) {
                    //alert(err + action.savedElements.placedElements[key]);
                }
            });
            action.saveStorage();
            document.getElementById('moveAllContainer').remove();
        } else {
            document.getElementById('moveAllContainer').remove();
        }
    });
    contain.appendChild(divBtn);

    msg = document.createElement('p');
    msg.className = "moveAllMessage";
    msg.innerHTML = "Enter a number value if you want to move everything up enter a negative value, if you want to move everything down use a positive value.";
    contain.appendChild(msg);

    document.getElementById('container').appendChild(contain);
};
