/* 

    Animations
    fsAnimation.checkAnimations is called by the tweak. It will pass info from settings
    letting the function know which animations are enabled.

*/

var fsAnimations = {
  rain: ['rain.html', 'rainwclouds.html', 'rainangleright.html', 'rainangleleft.html'],
  clouds: ['clouds.html', 'clouds2.html', 'clouds3.html', 'clouds4.html'],
  sun: ['sun.html'],
  snow: ['snow.html', 'snow1.html'],
  moon: ['moon.html'],
  thunderstorm: ['thunderstorm.html', 'thunderstormwclouds.html'],
  weatherURL: 'extras/animation/weather/',
  weather: false,
  birds: false,
  mp4: false,
  space: false,
  fireflies: false,
  spaceroad: false,
  spiral: false,
  globe: false,
  gif: false,
  createFrame: function(id, url, width) {
    var frame = document.createElement('iframe');
        frame.frameBorder = 0;
        frame.width = width;
        frame.height = screen.height;
        frame.style.pointerEvents = "none";
        frame.id = id;
        document.body.appendChild(frame);
        setTimeout(function(){
          frame.setAttribute("src", url);
        }, 0);
  },
  getRandomURL: function(type) {
    var random = Math.floor(Math.random() * type.length);
        return type[random];
  },
  getWeatherURL: function() {
    var array = null,
        picked = null;

    if(injectedWeather.conditionCode === undefined){
        injectedWeather.conditionCode = 34;
    }
    //injectedWeather.conditionCode = 11;
    if([32, 36].indexOf(Number(injectedWeather.conditionCode)) > -1){
        array = fsAnimations.sun;
    }else if([0, 19, 20, 21, 22, 26, 27, 28, 29, 30, 44, 34, 33].indexOf(Number(injectedWeather.conditionCode)) > -1){
        array = fsAnimations.clouds;
    }else if([8, 9, 10, 11, 12, 17, 18, 35].indexOf(Number(injectedWeather.conditionCode)) > -1){
        array = fsAnimations.rain;
    }else if([5, 6, 7, 13, 14, 15, 16, 41, 42, 43, 46].indexOf(Number(injectedWeather.conditionCode)) > -1){
        array = fsAnimations.snow;
    }else if([31].indexOf(Number(injectedWeather.conditionCode)) > -1){
        array = fsAnimations.moon;
    }else if([1, 2, 3, 4, 37, 38, 39, 45, 47].indexOf(Number(injectedWeather.conditionCode)) > -1){
        array = fsAnimations.thunderstorm;
    }
    
    //spacereturn this.weatherURL + fsAnimations.thunderstorm[1];
    picked = this.weatherURL + this.getRandomURL(array);
    //alert(picked);
    return picked;
  },
  showCharging: function(html){
    injectedSystem.chargetext = "Charging";
    systemdivs(true);
    if(!document.getElementById('batteryAnimation')){
      this.createFrame('batteryAnimation', 'extras/animation/random/battery/' + html, 320);
    }
  },
  removeCharging: function(){
    //document.getElementById('test').innerHTML += "removed battery";
    injectedSystem.chargetext = "Not Charging";
    systemdivs(true);
    if(document.getElementById('batteryAnimation')){
      document.getElementById('batteryAnimation').parentElement.removeChild(document.getElementById('batteryAnimation'));
    }
  },
  removeAnimations: function(){
    try{
        //document.getElementById('test').innerHTML += "removed all animations";
    var doc = document,
        weather = doc.getElementById('weatherFrame'),
        birds = doc.getElementById('birdsFrame'),
        mp4 = doc.getElementById('mp4Frame'),
        gif = doc.getElementById('gifFrame'),
        space = doc.getElementById('spaceFrame'),
        fireflies = doc.getElementById('fireflies'),
        spaceroad = doc.getElementById('spaceroad'),
        spiral = doc.getElementById('spiralFrame'),
        globe = doc.getElementById('globeFrame');
        if(weather){
          weather.parentElement.removeChild(weather);
        }
        if(birds){
          birds.parentElement.removeChild(birds);
        }
        if(mp4){
          mp4.parentElement.removeChild(mp4);
        }
        if(gif){
          gif.parentElement.removeChild(gif);
        }
        if(space){
          space.parentElement.removeChild(space);
        }
        if(fireflies){
          fireflies.parentElement.removeChild(fireflies);
        }
        if(spaceroad){
          spaceroad.parentElement.removeChild(spaceroad);
        }
        if(spiral){
          spiral.parentElement.removeChild(spiral);
        }
        if(globe){
          globe.parentElement.removeChild(globe);
        }
      }catch(err){
        location.href = "js-call:debugThis:" + err;
      }
  },
  checkAnimations: function(birds, weather, mp4, space, fireflies, spaceroad, globe, spiral, gif) {
    //location.href = "js-call:debugThis:Loading animations";
    if(weather == 1){
        //give time for weather to reload
        setTimeout(function(){
            if(document.getElementById('weatherFrame')){
              document.getElementById('weatherFrame').parentElement.removeChild(document.getElementById('weatherFrame'));
            }
            fsAnimations.createFrame('weatherFrame', fsAnimations.getWeatherURL(), 320);
            //fsAnimations.weather = true;
        }, 100);
    }
    if(birds == 1){
        this.createFrame('birdsFrame', 'extras/animation/birds/index.html', screen.width);
    }
    if(mp4 == 1){
        this.createFrame('mp4Frame', 'extras/animation/mp4/index.html', 320);
    }
    if(gif == 1){
        this.createFrame('gifFrame', 'extras/animation/gif/index.html', 320);
    }
    if(space == 1){
        this.createFrame('spaceFrame', 'extras/animation/random/space/index.html', 320);
    }
    if(fireflies == 1){
        this.createFrame('firefliesFrame', 'extras/animation/random/fireflies.html', 320);
    }
    if(spaceroad == 1){
        this.createFrame('spaceroadFrame', 'extras/animation/random/spaceroad.html', 320);
    }
    if(spiral == 1){
        this.createFrame('spiralFrame', 'extras/animation/random/spiral.html', 320);
    }
    if(globe == 1){
        this.createFrame('globeFrame', 'extras/animation/random/globe.html', 320);
    }
    //this.createFrame('spaceFrame', 'extras/animation/random/space/index.html', 320);
  }
};
