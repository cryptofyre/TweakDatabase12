

function math.round(x)
    return math.floor(x + 0.5)
end
