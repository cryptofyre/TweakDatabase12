function removeGradient(){
		var element = document.getElementById(action.selectedItem);
		action.savedElements.placedElements[action.selectedItem]['background'] = 'inherit';
		action.savedElements.placedElements[action.selectedItem]['-webkit-background-clip'] = 'inherit';
		action.savedElements.placedElements[action.selectedItem]['-webkit-text-fill-color'] = 'inherit';
		action.saveStorage();

		element.style.background = 'inherit';
		element.style.webkitBackgroundClip = 'inherit';
		element.style.webkitTextFillColor = 'inherit';
}

function getColors(type){
	var prmpt = prompt("How many colors is this gradient?"),
	colorArray = [];
	percentArray = [];
	if(prmpt && prmpt > 1){
		for (var i = 0; i < prmpt; i++) {
			var p = prompt("Enter #" + (i + 1) + " color");
			var per = prompt("Enter percentage for the " + type + " for color #" + (i + 1) + "Enter a value from 0 to 100, 0 being top or left and 100 being bottom or right.");
			percentArray.push(per);
			colorArray.push(p);
		}
		var final = "linear-gradient(";
		if(type == 'top'){
			final += "to bottom,";
		}else{
			final += "to right,"
		}
		for (var e = 0; e < colorArray.length; e++) {
			final += colorArray[e] + " " + percentArray[e] + '%';
			if((e + 1) != colorArray.length){
				final += ', ';
			}
		}
		final += ')';

		var element = document.getElementById(action.selectedItem);

		action.savedElements.placedElements[action.selectedItem]['background'] = final;
		action.savedElements.placedElements[action.selectedItem]['-webkit-background-clip'] = 'text';
		action.savedElements.placedElements[action.selectedItem]['-webkit-text-fill-color'] = 'transparent';
		action.saveStorage();

		element.style.background = final;
		element.style.webkitBackgroundClip = 'text';
		element.style.webkitTextFillColor = 'transparent';
		document.getElementById('textGradient').parentElement.removeChild(document.getElementById('textGradient'));
	}else{
		alert('You must have at least two colors');
	}
}

function createGradient(){
	var prmpt = confirm('Do you want a top to bottom gradient?', '');
	if(prmpt){
		getColors('top');
	}else{
		prmpt = confirm('Do you want a left to right gradient?', '');
		if(prmpt){
			getColors('left');
		}
	}
}

action.textGradient = function(){
	var container = document.createElement('div'),
		close = document.createElement('div'),
		addNew = document.createElement('div'),
		remove = document.createElement('div');

		container.className = 'textGradient';
		container.id = 'textGradient';
		close.innerHTML = "close";
		close.className = 'btns';
		remove.className = 'btns';
		remove.innerHTML = "Remove Gradient";
		addNew.className = 'btns';
		addNew.innerHTML = "Add Gradient";
		close.onclick = function(){
			this.parentElement.parentElement.removeChild(this.parentElement);
		}
		addNew.onclick = function(){
			createGradient();
		}
		remove.onclick = function(){
			removeGradient();
		}
		container.appendChild(addNew);
		container.appendChild(remove);
		container.appendChild(close);
		document.body.appendChild(container);
};

