/*jslint browser: true*/
/*global  $*/
/*global  action*/
/*global  elementPanel*/

'use strict';
var menu = {};

menu.disabledItems = [];

menu.screenClick = function (event) {
    menu.externalShadowMenu.removeMenu();
    $('#widgetlist').remove();
    if (action.selectedItem !== '') {
        $('#bottomMenu').remove();
        menu.bottomMenu();
        $('#editDragger').css('display', 'block');
        if ($('#bottomMenu').hasClass(action.selectedItem + "Menu")) {
            $('#bottomMenu').css('display', 'block');
        } else {
            $('#editDragger').css('display', 'block');
            $('#bottomMenu').remove();
            menu.bottomMenu();
        }
    } else {
        $('#editDragger').css('display', 'none');
        $('#bottomMenu').remove();
    }
};

menu.stylesMenu = function(el){
    var styleHolder = document.getElementById('copyHolder'),
        elementStyles = action.savedElements.placedElements[el],
        currentElement = document.getElementById(action.selectedItem),
        divClose = document.createElement('div'),
        style;
        divClose.innerHTML = "Close Menu";
        styleHolder.innerHTML = "";
        divClose.onclick = function(){
            document.body.removeChild(document.getElementById('copyHolder'));
        };
        styleHolder.appendChild(divClose);

    for(style in elementStyles){
        var div = document.createElement('div');
            div.innerHTML = style;
            div.onclick = function(){
                this.style.opacity = '0.4';
                currentElement.style[this.innerHTML] = elementStyles[this.innerHTML];
                action.savedElements.placedElements[action.selectedItem][this.innerHTML] = elementStyles[this.innerHTML];
                action.saveStorage();
            };
            styleHolder.appendChild(div);
    }
};

menu.copyStyle = function(){
    var copyHolder = document.createElement('div'),
        divClose = document.createElement('div');
        copyHolder.className = 'copyHolder';
        copyHolder.id = 'copyHolder';
        divClose.innerHTML = "Close Menu";
        divClose.onclick = function(){
            document.body.removeChild(document.getElementById('copyHolder'));
        };
        copyHolder.appendChild(divClose);
    for(var string in action.savedElements.placedElements){
        var div = document.createElement('div');
            div.innerHTML = string;
            div.onclick = function(){
                menu.stylesMenu(this.innerHTML);
            };
            copyHolder.appendChild(div);
    }
    document.body.appendChild(copyHolder);
};

menu.closeBottomMenu = function(){
    if($('#bottomMenu')){
        $('#editDragger').css('display', 'none');
        $('#bottomMenu').remove();
        $('#' + action.selectedItem).css('outline', '0px solid transparent');
        action.selectedItem = "";
    }
};

menu.toggle = function () {
    var display = $('.sidePanel').css('display');
    if (display === 'none') {
        $('.sidePanel').css('display', 'block');
    } else {
        $('.sidePanel').css('display', 'none');
    }
    menu.closeBottomMenu(); //close edit item menu
};
menu.button = function () {

    var rMenu = $('<div id="roundmenu"></div>');
    var redo = $('<div id="redomenu">Redo</div>');
    var undo = $('<div id="undomenu">Undo</div>');
    var enable = $('<div id="enablemenu">Unlock</div>');
    $('#container').append(rMenu);
    $('#container').append(redo);
    $('#container').append(undo);
    $('#container').append(enable);
    rMenu.draggable({
        stop: function (event, ui) {
            var halfWidth = $('#roundmenu').width() / 2; // These are probably the same but you never know

            var horizontalCenter = ui.position.left + halfWidth;
            var newLeft = $('#roundmenu').position().left;
            var newTop = $('#roundmenu').position().top;

            var smallestDistance = screen.width - horizontalCenter; // Distance to right
            newLeft = screen.width - halfWidth;
            if (horizontalCenter < smallestDistance) { // Distance to left
                smallestDistance = horizontalCenter;
                newLeft = 0 - halfWidth;
            }

            if (newTop + $('#roundmenu').height() > screen.height - 10) { // Below the bottom
                newTop = (screen.height - 10) - $('#roundmenu').height();
            } else if (newTop < 0) { // Above the top
                newTop = 4;
            }

            $('#roundmenu').animate({
                left: newLeft,
                top: newTop
            }, 700, 'easeOutElastic');
        }
    });

    rMenu.click(function () {
        menu.toggle();
        action.removePlacedElementsList();
    });
    redo.click(function(){
        action.redo();
    });
    undo.click(function(){
        action.undo();
    });
    enable.click(function(){
        for (var i = 0; i < menu.disabledItems.length; i++) {
            document.getElementById(menu.disabledItems[i]).style.pointerEvents = "initial";
        }
        document.getElementById('enablemenu').style.display = 'none';
    });
};
//end round menu button

// + or - buttons
menu.inputClick = function (button) {
    var input = button.parent().find("input"),
        oldValue = input.val(),
        clas = button.parent().find("input")[0].id.replace('manual', ''),
        currentValue,
        maxValue = 320;
        
    //console.log(input[0].id);

    if (button.text() === "+") {
        currentValue = parseFloat(oldValue) + 1;
    } else {
        if (oldValue > 0) {
            currentValue = parseFloat(oldValue) - 1;
        } else {
            currentValue = 0;
        }
    }

    //if rotation element stop at 360 not 320
    if(input[0].id){
        if(input[0].id.indexOf('Rotate') !== -1){
            maxValue = 360;
        }
        if(input[0].id.indexOf('height') !== -1){
            maxValue = 900;
        }
    }

    if (currentValue > maxValue) {
        currentValue = maxValue;
    }

    button.parent().find("input").val(currentValue);
    menu.adjustManual(clas, currentValue);

    function tryRepeat(button){
        var timeout = null;
        if(menu.touching == false){
            clearTimeout(timeout);
        }else{
            timeout = setTimeout(menu.inputClick, 0, button);
        }
    }
    setTimeout(tryRepeat, 100, button);
};

menu.updatePosition = function (left, top) {
    $('.topInput').val(top);
    $('.leftInput').val(left);
};

var customDivs = {
    names: [],
    data: {}
};

//check array to see what numbers have been used.
function getDivName (counter){
    if(!counter){
        counter = 0;
    }
    if(customDivs.names.length > 0){
        if(customDivs.names.contains('customDiv' + counter)){
            return getDivName(counter + 1);
        }else{
            return counter;
        }
    }else{
        return 0;
    }
}

menu.customVars = function(){
    if(document.getElementById('customDivMenu')){
        return;
    }
    var customVar = null;
    if(customDivs.names.length > 0){
        var div = document.createElement('div'),
            create,
            extra,
            close;
            div.className = 'customDivMenu';
            div.id = 'customDivMenu';
            document.body.appendChild(div);
            for (var i = 0; i < customDivs.names.length; i++) {
                create = document.createElement('div');
                create.innerHTML = customDivs.names[i];
                create.style.color = "white";
                create.onclick = function(){
                    div.parentElement.removeChild(div);
                    customDivs.data[this.innerHTML].push(action.selectedItem);
                    customVar = this.innerHTML;
                    action.savedElements.placedElements[customVar]['data-vars'] = customDivs.data[customVar];
                    action.saveStorage();
                    //document.getElementById(customVar).style['data-vars'] = JSON.stringify(customDivs);
                    document.getElementById(this.innerHTML).appendChild(document.getElementById(action.selectedItem));
                }
                div.appendChild(create);
            }
            extra = document.createElement('div');
            extra.innerHTML = "Add Div";
            extra.style.color = "white";
            extra.onclick = function(){
                div.parentElement.removeChild(div);
                var customName = 'customDiv' + getDivName();
                action.addtoScreen(customName, action.selectedItem);
                customDivs.names.push(customName);
                customDivs.data[customName] = [action.selectedItem];
                customVar = customName;
                //document.getElementById(customVar).style['data-vars'] = JSON.stringify(customDivs);
                action.savedElements.placedElements[customVar]['data-vars'] = customDivs.data[customVar];
                action.saveStorage();
            }
            close = document.createElement('div');
            close.innerHTML = "Close Panel";
            close.style.color = "white";
            close.onclick = function(){
                div.parentElement.removeChild(div);
            }
            div.appendChild(extra);
            div.appendChild(close);
    }else{
        var customName = 'customDiv' + getDivName();
        action.addtoScreen(customName, action.selectedItem);
        customDivs.names.push(customName);
        customDivs.data[customName] = [action.selectedItem];
        customVar = customName;
        //document.getElementById(customVar).style['data-vars'] = JSON.stringify(customDivs);
        action.savedElements.placedElements[customVar]['data-vars'] = customDivs.data[customVar];
        action.saveStorage();
    }
    
};

menu.openAnimations = function(){
    if(document.getElementById('aniMenu')){
        return;
    }
    var menu = document.createElement('div'),
        animations = ['fade', 'aniUp', 'aniDown', 'aniLeft', 'aniRight'],
        el, close;
        for (var i = 0; i < animations.length; i++) {
            el = document.createElement('div');
            el.innerHTML = animations[i];
            el.className = 'elAnimations';
            menu.appendChild(el);
        }
        close = document.createElement('div');
        close.innerHTML = 'Close Panel';
        close.className = 'elAnimationsClose';
        menu.appendChild(close);
        menu.id = 'aniMenu';
        menu.onclick = function(el){
            var target;
            if(el.target.className === 'elAnimations'){
                target = el.target.innerHTML;
                if(target === 'aniUp'){
                    if(action.savedElements.placedElements[action.selectedItem]['aniDown']){
                        alert("You have set aniDown remove it by setting it to 0 before setting aniUp.");
                        return;
                    }
                }else if(target === 'aniDown'){
                    if(action.savedElements.placedElements[action.selectedItem]['aniUp']){
                        alert("You have set aniUp remove it by setting it to 0 before setting aniDown.");
                        return;
                    }
                }else if(target === 'aniLeft'){
                    if(action.savedElements.placedElements[action.selectedItem]['aniRight']){
                        alert("You have set aniRight remove it by setting it to 0 before setting aniLeft.");
                        return;
                    }
                }else if(target === 'aniRight'){
                    if(action.savedElements.placedElements[action.selectedItem]['aniLeft']){
                        alert("You have set aniLeft remove it by setting it to 0 before setting aniRight.");
                        return;
                    }
                }
                var prmpt = prompt('Animations speed in milliseconds. Example 1000 to remove animation press cancel');
                    if(prmpt > 0){
                        action.savedElements.placedElements[action.selectedItem][el.target.innerHTML] = prmpt;
                    }else{
                        delete action.savedElements.placedElements[action.selectedItem][el.target.innerHTML];
                    }
                    action.saveStorage();
            }else if (el.target.className === 'elAnimationsClose'){
                document.body.removeChild(menu);
            }
        };
        menu.className = 'animationMenu';
    document.body.appendChild(menu);
};
function encode(r){
    return r.replace(/[\x26\x0A\<>'"]/g,function(r){return"&#"+r.charCodeAt(0)+";"})
}
menu.createButtons = function (id, name) {
    var button = document.createElement('div');
    button.innerHTML = 'Open';
    button.className = 'openButtons';
    if(name === 'disabled'){
        button.innerHTML = "Lock Element";
        button.onclick = function () {
            document.getElementById(action.selectedItem).style.pointerEvents = 'none';
            document.getElementById('enablemenu').style.display = 'block';
            menu.disabledItems.push(action.selectedItem);
            handleScreenClick(event);
            elPanel.screenClick();
            menu.screenClick(event);
            $('.sidePanel').css('display', 'none');
        }
    }
    if (name === 'color' || name === 'boxColor') {
        button.onclick = function () {
            if (action.selectedItem.substring(0, 3) === 'box') {
                action.cgcolor(false, 'background-color', 'BMboxColor');
            } else {
                action.cgcolor(false, 'color', 'bottomMenu');
            }
        };
    }else if (name === 'textGradient'){
        button.onclick = function(){
            action.textGradient();
        }
    }else if (name === 'animations'){
        button.innerHTML = 'Animations';
        button.onclick = function(){
            menu.openAnimations();
        };
    }else if (name === 'copyStyle'){
        button.innerHTML = 'Select';
        button.onclick = function(){
            menu.copyStyle();
        };  
    }else if (name === 'center'){
        button.innerHTML = "Center";
        button.onclick = function(){
            var el = document.getElementById(action.selectedItem),
            screenW = screen.width,
            center = 320 / 2 - el.offsetWidth / 2 + "px";
            action.setCss(action.selectedItem, 'left', center);
            //$('#' + action.selectedItem).css('left', center);
        };
    }else if (name === 'Battery'){
        //using squares as battery line
        button.innerHTML = "Add";
        try{
        if(action.savedElements.placedElements[action.selectedItem]['is-battery']){
            if(action.savedElements.placedElements[action.selectedItem]['is-battery'] === 'true'){
                button.innerHTML = "Remove";
            }
        }
        button.onclick = function(){
            if(action.savedElements.placedElements[action.selectedItem]['is-battery']){
                if(action.savedElements.placedElements[action.selectedItem]['is-battery'] === 'true'){
                    action.savedElements.placedElements[action.selectedItem]['is-battery'] = 'false';
                    this.innerHTML = "Add";
                }else{
                    action.savedElements.placedElements[action.selectedItem]['is-battery'] = 'true';
                    this.innerHTML = "Remove";
                }
            }else{
               action.savedElements.placedElements[action.selectedItem]['is-battery'] = 'true';
               this.innerHTML = "Remove"; 
            }
            action.saveStorage();
        }
        }catch(err){
            alert(err);
        }
    }else if (name === 'triColor'){
        button.onclick = function(){
            action.cgcolor(false, 'border-bottom-color', 'BMtriColor');
        };
    } else if (name === 'fonts') {
        button.onclick = function () {
            try{
                action.cgfont();
            }catch(err){
                alert(err);
            }
        };
    } else if (name === 'delete') {
        button.innerHTML = 'Delete';
        button.onclick = function () {
            var customDivIndex,
                customDivChildren,
                screenElements;

            //remove item from customDivs (divs that contain items)
            //also move items that it contains back to the main screen
            if(action.selectedItem.substring(0, 9) === 'customDiv'){
                screenElements = document.getElementById("screenElements");
                customDivChildren = customDivs.data[action.selectedItem];
                customDivIndex = customDivs.names.indexOf(action.selectedItem);

                //move items that are contained
                for (var i = 0; i < customDivChildren.length; i++) {
                    screenElements.appendChild(document.getElementById(customDivChildren[i]));
                }
                
                //if in array remove it also remove the object   
                if (customDivIndex > -1) {
                  customDivs.names.splice(customDivIndex, 1);
                  delete customDivs.data[action.selectedItem];
                }
            }

            //remove item from the screen
            action.removeItemFromScreen(action.selectedItem);

            if ($.inArray(action.selectedItem, constants.widgets) === -1) {
                action.widgetLoaded = false;
            }


            if (!action.isScrollingEdit) {
                handleScreenClick(event);
                elPanel.screenClick();
                menu.screenClick(event);
                $('.sidePanel').css('display', 'none');
            }

            $("#accordion").find("li[title='" + action.selectedItem + "']").removeClass();
        };
    } else if (name == 'addtext') {
        button.innerHTML = 'Enter Text';
        button.onclick = function () {
            var prmpt = prompt("Enter full text", "");
                prmpt = $('<div/>').text(prmpt).html();
            if (prmpt != null) {
                $('#' + action.selectedItem).html(prmpt);
                action.savedElements.placedElements[action.selectedItem].innerHTML = prmpt //Saves to localStorage
                action.saveStorage();
            }
        };
    }else if (name == 'adddiv') {
        button.innerHTML = 'Add to div';
        button.onclick = function () {
            menu.customVars();
        };
    } else if (name === 'changeicon') {
        button.innerHTML = 'Change Icon';
        button.onclick = function () {
            action.populateIcons();
        };
    } else if (name === 'shadow') {
        button.innerHTML = "Open Shadow";
        button.onclick = function () {
            menu.externalShadowMenu.createMenu('text-shadow', 3, ['x', 'y', 'blur'], action.selectedItem);
            $('#bottomMenu').remove();
            $('#editDragger').css('display', 'none');
        };
    }else if (name === 'boxShadow'){
        //console.log("line 247 boxShadow");
        button.innerHTML = "Open Shadow";
        button.onclick = function () {
            menu.externalShadowMenu.createMenu('box-shadow', 3, ['x', 'y', 'blur'], action.selectedItem);
            $('#bottomMenu').remove();
            $('#editDragger').css('display', 'none');
        };
    }

    document.getElementById(id).appendChild(button);
};
menu.touching = false;

menu.createPositionInputs = function (name, does) {
    if (does === 'top-left') {
        var first = does.split('-')[0]; //top
        var second = does.split('-')[1]; //left
    }

    var startVal1 = $('#' + action.selectedItem).css(first).replace(/[^-\d\.]/g, ''); //top
    var startVal2 = $('#' + action.selectedItem).css(second).replace(/[^-\d\.]/g, ''); //left
    //var startVal2 =

    var inputContainer = document.createElement('div'),
        inputContainer2 = document.createElement('div'),
        input1 = document.createElement('input'),
        increment = document.createElement('div'),
        decrement = document.createElement('div'),
        input2 = document.createElement('input'),
        increment1 = document.createElement('div'),
        label1 = document.createElement('div'),
        label2 = document.createElement('div'),
        decrement1 = document.createElement('div');

    inputContainer.className = 'inputContainer';
    inputContainer2.className = 'inputContainer2';

    label1.innerHTML = 'top';
    label1.className = 'topLabel';
    label2.innerHTML = 'left';
    label2.className = 'leftLabel';

    //top
    input1.type = 'text';
    input1.value = Math.round(startVal1);
    input1.id = 'manual' + name;
    input1.className = 'manualInput topInput';
    //left
    input2.type = 'text';
    input2.value = Math.round(startVal2);
    input2.id = 'manual' + name;
    input2.className = 'manualInput leftInput';

    //top
    increment.className = 'incs inButton';
    increment.ontouchstart = function () {
        menu.touching = true;
        menu.inputClickTop($(this), first);
    };
    increment.ontouchend = function () {
        menu.touching = false;
    };
    increment.ontouchcancel = function(){
        menu.touching = false;
    };

    if(!mobilecheck()){
        increment.onmousedown = function(){
            menu.touching = true;
            menu.inputClickTop($(this), first);
        };
        increment.onmouseup = function(){
            menu.touching = false;
        };
        decrement.onmousedown = function(){
            menu.touching = true;
            menu.inputClickTop($(this), first);
        };
        decrement.onmouseup = function(){
            menu.touching = false;
        };
        increment1.onmousedown = function(){
            menu.touching = true;
            menu.inputClickTop($(this), second);
        };
        increment1.onmouseup = function(){
            menu.touching = false;
        };
        decrement1.onmousedown = function(){
            menu.touching = true;
            menu.inputClickTop($(this), second);
        };
        decrement1.onmouseup = function(){
            menu.touching = false;
        };
    }
    increment.innerHTML = '+';

    //left
    increment1.className = 'incs inButton';
    increment1.ontouchstart = function () {
        menu.touching = true;
        menu.inputClickTop($(this), second);
    };
    increment1.ontouchend = function () {
        menu.touching = false;
    };
    increment1.ontouchcancel = function(){
        menu.touching = false;
    };
    increment1.innerHTML = '+';

    //top
    decrement.className = 'decs inButton';
    decrement.ontouchstart = function () {
        menu.touching = true;
        menu.inputClickTop($(this), first);
    }
    decrement.ontouchend = function () {
        menu.touching = false;
    };
    decrement.ontouchcancel = function(){
        menu.touching = false;
    };
    decrement.innerHTML = '-';

    //left
    decrement1.className = 'decs inButton';
    decrement1.ontouchstart = function () {
        menu.touching = true;
        menu.inputClickTop($(this), second);
    }
    decrement1.ontouchend = function () {
        menu.touching = false;
    };
    decrement1.ontouchcancel = function(){
        menu.touching = false;
    };
    decrement1.innerHTML = '-';
    //top
    inputContainer.appendChild(label1);
    inputContainer.appendChild(increment);
    inputContainer.appendChild(decrement);
    inputContainer.appendChild(input1);
    //left
    inputContainer2.appendChild(label2);
    inputContainer2.appendChild(increment1);
    inputContainer2.appendChild(decrement1);
    inputContainer2.appendChild(input2);

    document.getElementById(name).appendChild(inputContainer);
    document.getElementById(name).appendChild(inputContainer2);


};


menu.inputClickTop = function (button, css) {
    var oldValue = button.parent().find("input").val(),
        newVal;
    if (button.text() === "+") {
        newVal = parseFloat(oldValue) + 1;
    } else {
        if (oldValue > 0) {
            newVal = parseFloat(oldValue) - 1;
        } else {
            newVal = 0;
        }
    }
    if (newVal > 660) {
        newVal = 660;
    }
    button.parent().find("input").val(newVal);
    menu.adjust(css, newVal, true);
    //repeat when held down defined by menu.touching
    function tryRepeat(button, css){
        var timeout = null;
        if(menu.touching == false){
            clearTimeout(timeout);
        }else{
            timeout = setTimeout(menu.inputClickTop, 0, button, css);
        }
    }
    setTimeout(tryRepeat, 100, button, css);
};


menu.getRotationDegrees = function(obj) {
    var matrix = obj.css("-webkit-transform");
    if(matrix !== 'none') {
        var values = matrix.split('(')[1].split(')')[0].split(',');
        var a = values[0];
        var b = values[1];
        var angle = Math.round(Math.atan2(b, a) * (180/Math.PI));
    } else { var angle = 0; }
    return (angle < 0) ? angle + 360 : angle;
};


menu.createRange = function (name, does) {

    var slideCon = document.createElement('div'),
        input = document.createElement('input'),
        range = document.createElement('div');

    slideCon.className = 'slider-wrapper';
    slideCon.id = 'sliderContainer' + name;

    document.getElementById(name).appendChild(slideCon);

    input.type = 'text';
    input.className = name + 'js-opacity';
    input.id = 'range' + name;

    document.getElementById('sliderContainer' + name).appendChild(input);

    range.className = 'powerranger js-change-opacity';
    document.getElementById('sliderContainer' + name).appendChild(range);

    var opct = document.querySelector('.' + name + 'js-opacity');
    var startVal = null;
    var decimal = false;
    var min = 0;
    var max = 0;
    var div;

    if (name == 'BMiconsize') {
        startVal = $('#iconImg' + action.selectedItem).css(does).replace(/[^-\d\.]/g, '');
        decimal = false;
        max = 420;
    } else {
        if (name == 'BMwidgetsize') {
            //get scale value for startval if one is set.
            div = $('#' + action.selectedItem).css('transform');
            var values = div.split('(')[1];
            values = values.split(')')[0];
            values = values.split(',');
            startVal = values[0] || 1;
            decimal = true;
            max = 5;
        } else if (name == 'BMtriSize'){
            startVal = parseInt($("#" + action.selectedItem).css("border-bottom-width"), 10);
            min = 5;
            max = 320;
        } else if(name == 'BMtriRotate'){ //set startVal for rotation
            startVal = menu.getRotationDegrees($('#' + action.selectedItem));
            max = 360;
        }else if(name == 'BMzindex'){
            startVal = $('#' + action.selectedItem).css('z-index');
            max = 10;
        } else if (name == 'BMRotate'){
            startVal = menu.getRotationDegrees($('#' + action.selectedItem));
            max = 360;
        } else if (name == 'BMheight'){
            startVal = $('#' + action.selectedItem).css(does).replace(/[^-\d\.]/g, '');
            decimal = false;
            max = 900;
        } else {
            startVal = $('#' + action.selectedItem).css(does).replace(/[^-\d\.]/g, '');
            decimal = false;
            max = 320;
        }
    }

    var initOpct = new Powerange(opct, {
        callback: function () {
            menu.adjust(name);
        },
        decimal: decimal,
        min: min,
        max: max,
        start: startVal,
        hideRange: true
    });
    if (name != 'BMwidgetsize') {
        var inputContainer = document.createElement('div');
        inputContainer.className = 'inputContainer';
        var input2 = document.createElement('input');
        input2.type = 'text';
        input2.value = startVal;
        input2.id = 'manual' + name;
        input2.className = 'manualInput';
        var increment = document.createElement('div');
        var decrement = document.createElement('div');
        increment.className = 'incs inButton';
        increment.ontouchstart = function () {
            menu.touching = true;
            menu.inputClick($(this));
        }
        increment.ontouchend = function(){
            menu.touching = false;
        }
        increment.innerHTML = '+';
        decrement.className = 'decs inButton';
        decrement.ontouchstart = function () {
            menu.touching = true;
            menu.inputClick($(this));
        }
        decrement.ontouchend = function(){
            menu.touching = false;
        }
        decrement.innerHTML = '-';
        input2.onchange = function () {
            menu.adjustManual(name, this.value);
        }

        //web
        if(!mobilecheck()){
            increment.onmousedown = function () {
                menu.touching = true;
                menu.inputClick($(this));
            };
            increment.onmouseup = function(){
                menu.touching = false;
            };
            decrement.onmousedown = function () {
                menu.touching = true;
                menu.inputClick($(this));
            };
            decrement.onmouseup = function(){
                menu.touching = false;
            };
        }
        inputContainer.appendChild(increment);
        inputContainer.appendChild(decrement);
        inputContainer.appendChild(input2);
        document.getElementById(name).appendChild(inputContainer);
    }

};

menu.adjustManual = function (name, value) {
    //should change powerange here, but it's being a bitch
    this.adjust(name, String(value), true);

};
menu.adjust = function (adjustItem, value, manual) {
    if (!manual) {
        $('#manual' + adjustItem).val(document.getElementById('range' + adjustItem).value);
    }
    if (action.selectedItem.length > 0) {
        if (value || value === 0) { //fix if left is set to 0
            switch (adjustItem) {
            case 'BMtriSize':
                action.setCss(action.selectedItem, 'border-left', value + 'px solid transparent');
                action.setCss(action.selectedItem, 'border-right', value + 'px solid transparent');
                action.setCss(action.selectedItem, 'border-bottom', value + 'px solid ' + document.getElementById(action.selectedItem).style.borderBottomColor);
                break;
            case 'BMzindex':
                action.setCss(action.selectedItem, 'z-index', value);
                break;
            case 'BMtriRotate':
                action.setCss(action.selectedItem, '-webkit-transform', 'rotate(' + value + 'deg)');
                break;
            case 'BMRotate':
                action.setCss(action.selectedItem, '-webkit-transform', 'rotate(' + value + 'deg)');
                break;
            case 'BMsize':
                action.setCss(action.selectedItem, 'font-size', value + 'px');
                break;
            case 'BMwidth':
                action.setCss(action.selectedItem, 'width', value + 'px');
                break;
            case 'BMheight':
                action.setCss(action.selectedItem, 'height', value + 'px');
                break;
            case 'BMradius':
                action.setCss(action.selectedItem, 'border-radius', value + 'px');
                break;
            case 'BMiconsize':
                action.setCss(action.selectedItem, 'width', value + 'px');
                $('#iconImg' + action.selectedItem).css('width', value + 'px');

                //action.setCss(action.selectedItem, 'height', value + 'px');
                //$('#iconImg' + action.selectedItem).css('height', value + 'px');
                //action.setCss('iconImg', 'width', value + 'px');
                break;
            case 'BMwidgetsize':
                action.setCss(action.selectedItem, '-webkit-transform', 'scale(' + value + ')');
                action.savedElements.placedElements[action.selectedItem]['-webkit-transform'] = 'scale(' + value + ')';
                //$('#' + action.selectedItem).css('-webkit-transform', 'scale(' + value + ')');
                //action.setCss('iconImg', 'width', value + 'px');
                break;
            case 'BMborder':
                action.setCss(action.selectedItem, 'border-width', value + 'px');
                break;
            case 'BMtextborder':
                action.setCss(action.selectedItem, '-webkit-text-stroke-width', value + 'px');
                break;
            case 'top':
                action.setCss(action.selectedItem, 'top', value + 'px');
                break;
            case 'left':
                action.setCss(action.selectedItem, 'left', value + 'px');
                break;
            default:
                'null';
            }
        } else {
            var value = 0;
            if(document.getElementById('range' + adjustItem)){
                value = document.getElementById('range' + adjustItem).value;
            }
            if (adjustItem === 'BMsize') {
                action.setCss(action.selectedItem, 'font-size', value + 'px');
            } else if (adjustItem === 'BMwidth') {
                action.setCss(action.selectedItem, 'width', value + 'px');
            } else if (adjustItem === 'BMheight') {
                action.setCss(action.selectedItem, 'height', value + 'px');
            } else if (adjustItem === 'BMtop') {
                action.setCss(action.selectedItem, 'top', value + 'px');
            } else if (adjustItem === 'BMradius') {
                action.setCss(action.selectedItem, 'border-radius', value + 'px');
            } else if (adjustItem === 'BMiconsize') {
                action.setCss(action.selectedItem, 'width', value + 'px');
                $('#iconImg' + action.selectedItem).css('width', value + 'px');
                //action.setCss(action.selectedItem, 'height', value + 'px');
                //$('#iconImg' + action.selectedItem).css('height', value + 'px');
            }else if(adjustItem === 'BMtriSize'){
                if(value > 5){
                    action.setCss(action.selectedItem, 'border-left', value + 'px solid transparent');
                    action.setCss(action.selectedItem, 'border-right', value + 'px solid transparent');
                    action.setCss(action.selectedItem, 'border-bottom', value + 'px solid ' + document.getElementById(action.selectedItem).style.borderBottomColor);
                }
            }else if(adjustItem === 'BMzindex'){
                action.setCss(action.selectedItem, 'z-index', value);
            }else if (adjustItem === 'BMtriRotate'){
                action.setCss(action.selectedItem, '-webkit-transform', 'rotate(' + value + 'deg)');
            }else if (adjustItem === 'BMRotate'){
                action.setCss(action.selectedItem, '-webkit-transform', 'rotate(' + value + 'deg)');
            } else if (adjustItem === 'BMwidgetsize') {
                action.setCss(action.selectedItem, '-webkit-transform', 'scale(' + value + ')');
            }
        }
    }

};

action.autoCenter = function(){
    action.setCss(action.selectedItem, 'left', '0');
    action.setCss(action.selectedItem, 'width', '320');
};

menu.createTriButtons = function (name, one, two, three) {
    var triContain = document.createElement('div'),
        first = document.createElement('div'),
        second = document.createElement('div'),
        third = document.createElement('div');

    triContain.className = 'triContain';

    first.className = 'firstTri';
    first.innerHTML = one;

    second.className = 'secondTri';
    second.innerHTML = two;

    third.className = 'thirdTri';
    third.innerHTML = three;
    if (name === 'BMalign') {
        first.onclick = function () {
            $('#' + action.selectedItem).css('text-align', 'left');
            action.savedElements.placedElements[action.selectedItem]['text-align'] = 'left';
            action.saveStorage();
        }
        second.onclick = function () {
            $('#' + action.selectedItem).css('text-align', 'center');
            action.savedElements.placedElements[action.selectedItem]['text-align'] = 'center';
            action.saveStorage();
        }
        third.onclick = function () {
            $('#' + action.selectedItem).css('text-align', 'right');
            action.savedElements.placedElements[action.selectedItem]['text-align'] = 'right';
            action.saveStorage();
        }
    } else if (name === "BMvertical") {
        first.onclick = function () {
            $('#' + action.selectedItem).css('-webkit-writing-mode', 'unset');
            $('#' + action.selectedItem).css('-webkit-text-orientation', 'unset');
            action.savedElements.placedElements[action.selectedItem]['-webkit-writing-mode'] = 'unset';
            action.savedElements.placedElements[action.selectedItem]['-webkit-text-orientation'] = 'unset';
            action.saveStorage();
        }
        second.onclick = function () {
            $('#' + action.selectedItem).css('-webkit-writing-mode', 'vertical-rl');
            $('#' + action.selectedItem).css('-webkit-text-orientation', 'upright');
            action.savedElements.placedElements[action.selectedItem]['-webkit-writing-mode'] = 'vertical-rl';
            action.savedElements.placedElements[action.selectedItem]['-webkit-text-orientation'] = 'upright';
            action.saveStorage();
        }
        third.onclick = function () {
            $('#' + action.selectedItem).css('-webkit-writing-mode', 'vertical-lr');
            $('#' + action.selectedItem).css('-webkit-text-orientation', 'upright');
            action.savedElements.placedElements[action.selectedItem]['-webkit-writing-mode'] = 'vertical-lr';
            action.savedElements.placedElements[action.selectedItem]['-webkit-text-orientation'] = 'upright';
            action.saveStorage();
        }
    } else if (name === 'BMuppercase') {
        first.onclick = function () {
            $('#' + action.selectedItem).css('text-transform', 'uppercase');
            action.savedElements.placedElements[action.selectedItem]['text-transform'] = 'uppercase';
            action.saveStorage();
            //menu.inputClick($(this));
        }
        second.onclick = function () {
            $('#' + action.selectedItem).css('text-transform', 'capitalize');
            action.savedElements.placedElements[action.selectedItem]['text-transform'] = 'capitalize';
            action.saveStorage();
        }
        third.onclick = function () {
            $('#' + action.selectedItem).css('text-transform', 'lowercase');
            action.savedElements.placedElements[action.selectedItem]['text-transform'] = 'lowercase';
            action.saveStorage();
        }
    } else if (name === 'BMstyle') {
        first.onclick = function () {
            $('#' + action.selectedItem).css('font-style', 'italic');
            action.savedElements.placedElements[action.selectedItem]['font-style'] = 'italic';
            action.saveStorage();
            //menu.inputClick($(this));
        }
        second.onclick = function () {
            $('#' + action.selectedItem).css('font-style', 'oblique');
            action.savedElements.placedElements[action.selectedItem]['font-style'] = 'oblique';
            action.saveStorage();
        }
        third.onclick = function () {
            $('#' + action.selectedItem).css('font-style', 'initial');
            action.savedElements.placedElements[action.selectedItem]['font-style'] = 'initial';
            action.saveStorage();
        }
    }else if (name === 'BMweight'){
        first.onclick = function(){
            $('#' + action.selectedItem).css('font-weight', '100');
            action.savedElements.placedElements[action.selectedItem]['font-weight'] = '100';
            action.saveStorage();

            // $('#' + action.selectedItem).css('background', '-webkit-linear-gradient(#eee, #333)');
            // $('#' + action.selectedItem).css('-webkit-background-clip', 'text');
            // $('#' + action.selectedItem).css('-webkit-text-fill-color', 'transparent');

        };
        second.onclick = function(){
            $('#' + action.selectedItem).css('font-weight', 'bold');
            action.savedElements.placedElements[action.selectedItem]['font-weight'] = 'bold';
            action.saveStorage();
            // $('#' + action.selectedItem).css('background', 'transparent');
            // $('#' + action.selectedItem).css('-webkit-background-clip', 'initial');
            // $('#' + action.selectedItem).css('-webkit-text-fill-color', 'initial');
        };
        third.onclick = function(){
            $('#' + action.selectedItem).css('font-weight', 'normal');
            action.savedElements.placedElements[action.selectedItem]['font-weight'] = 'normal';
            action.saveStorage();
        };
    }else if (name === 'BMblurbehind'){
        first.onclick = function(){
            $('#' + action.selectedItem).css('-webkit-backdrop-filter', 'blur(5px)');
            action.savedElements.placedElements[action.selectedItem]['-webkit-backdrop-filter'] = 'blur(5px)';
            action.saveStorage();
        };
        second.onclick = function(){
            $('#' + action.selectedItem).css('-webkit-backdrop-filter', 'blur(10px)');
            action.savedElements.placedElements[action.selectedItem]['-webkit-backdrop-filter'] = 'blur(10px)';
            action.saveStorage();
        };
        third.onclick = function(){
            $('#' + action.selectedItem).css('-webkit-backdrop-filter', 'blur(0px)');
            action.savedElements.placedElements[action.selectedItem]['-webkit-backdrop-filter'] = 'blur(0px)';
            action.saveStorage();
        };
    }else if (name === 'BMfade'){
        first.onclick = function(){
            var color = $('#' + action.selectedItem).css("color");
            $('#' + action.selectedItem).css('background', '-webkit-linear-gradient('+color+', #333)');
            $('#' + action.selectedItem).css('-webkit-background-clip', 'text');
            $('#' + action.selectedItem).css('-webkit-text-fill-color', 'transparent');
            action.savedElements.placedElements[action.selectedItem]['background'] = '-webkit-linear-gradient('+color+', #333)';
            action.savedElements.placedElements[action.selectedItem]['-webkit-background-clip'] = 'text';
            action.savedElements.placedElements[action.selectedItem]['-webkit-text-fill-color'] = 'transparent';
            action.saveStorage();

        };
        second.onclick = function(){
            var color = $('#' + action.selectedItem).css("color");
            $('#' + action.selectedItem).css('background', '-webkit-linear-gradient(#333, '+color+')');
            $('#' + action.selectedItem).css('-webkit-background-clip', 'text');
            $('#' + action.selectedItem).css('-webkit-text-fill-color', 'transparent');
            action.savedElements.placedElements[action.selectedItem]['background'] = '-webkit-linear-gradient(#333, '+color+')';
            action.savedElements.placedElements[action.selectedItem]['-webkit-background-clip'] = 'text';
            action.savedElements.placedElements[action.selectedItem]['-webkit-text-fill-color'] = 'transparent';
            action.saveStorage();
        };
        third.onclick = function(){
            $('#' + action.selectedItem).css('background', 'transparent');
            $('#' + action.selectedItem).css('-webkit-background-clip', 'initial');
            $('#' + action.selectedItem).css('-webkit-text-fill-color', 'initial');
            action.savedElements.placedElements[action.selectedItem]['background'] = 'transparent';
            action.savedElements.placedElements[action.selectedItem]['-webkit-background-clip'] = 'initial';
            action.savedElements.placedElements[action.selectedItem]['-webkit-text-fill-color'] = 'initial';
            action.saveStorage();
        };
    }else if (name === 'BMdecoration'){
        first.onclick = function(){
            $('#' + action.selectedItem).css('text-decoration', 'underline');
            action.savedElements.placedElements[action.selectedItem]['text-decoration'] = 'underline';
            action.saveStorage();

        };
        second.onclick = function(){
            $('#' + action.selectedItem).css('text-decoration', 'line-through');
            action.savedElements.placedElements[action.selectedItem]['text-decoration'] = 'line-through';
            action.saveStorage();
        };
        third.onclick = function(){
            $('#' + action.selectedItem).css('text-decoration', 'none');
            action.savedElements.placedElements[action.selectedItem]['text-decoration'] = 'none';
            action.saveStorage();
        };
    }else if (name === 'BMspacing'){
        first.onclick = function(){
            $('#' + action.selectedItem).css('letter-spacing', '2px');
            action.savedElements.placedElements[action.selectedItem]['letter-spacing'] = '2px';
            action.saveStorage();

        };
        second.onclick = function(){
            $('#' + action.selectedItem).css('letter-spacing', '5px');
            action.savedElements.placedElements[action.selectedItem]['letter-spacing'] = '5px';
            action.saveStorage();
        };
        third.onclick = function(){
            $('#' + action.selectedItem).css('letter-spacing', 'initial');
            action.savedElements.placedElements[action.selectedItem]['letter-spacing'] = 'initial';
            action.saveStorage();
        };
    }
    triContain.appendChild(first);
    triContain.appendChild(second);
    triContain.appendChild(third);
    document.getElementById(name).appendChild(triContain);
};

menu.createBorderButton = function (id) {
    var button = document.createElement('div');
    button.innerHTML = 'Color';
    button.className = 'borderButton';
    document.getElementById(id).appendChild(button);


    var inputContainer = document.createElement('div');
    inputContainer.className = 'inputContainer2';
    var input2 = document.createElement('input');
    input2.type = 'text';

    if(id === "BMtextborder"){
        button.onclick = function(){
            action.cgcolor(false, '-webkit-text-stroke-color', 'BMtextborder');
        };
        input2.value = $('#' + action.selectedItem).css('-webkit-text-stroke-width');
    }else if(id === "BMborder"){
        button.onclick = function () {
            action.cgcolor(false, 'border-color', 'BMborder');
        };
        input2.value = $('#' + action.selectedItem).css('border-width');
    }
    input2.id = 'manual' + id;
    input2.className = 'manualInput';
    var increment = document.createElement('div');
    var decrement = document.createElement('div');
    increment.className = 'incs inButton';
    increment.onclick = function () {
        menu.inputClick($(this));
    }
    increment.innerHTML = '+';
    decrement.className = 'decs inButton';
    decrement.onclick = function () {
        menu.inputClick($(this));
    }
    decrement.innerHTML = '-';
    input2.onchange = function () {
        menu.adjustManual(name, this.value);
    }
    inputContainer.appendChild(increment);
    inputContainer.appendChild(decrement);
    inputContainer.appendChild(input2);
    document.getElementById(id).appendChild(inputContainer);
};

menu.createAffixes = function(id, liName){
    var bmAffixes = document.createElement('li');
    bmAffixes.id = "BMaffixes";
    bmAffixes.className = "bottomMenuLI";
    document.getElementById('bottomMenuUL').appendChild(bmAffixes);

    var holderDiv = document.createElement('div');
    holderDiv.style.cssText = "width:100%; position:absolute; top:50%; -webkit-transform:translate(0%,-50%)";
    bmAffixes.appendChild(holderDiv);

    var prefix = document.createElement('div');
    prefix.id = "prefixDiv";
    prefix.innerHTML = '<div id="customPrefixDivWrapper" style="position:absolute;left:50%; -webkit-transform:translate(-50%,0%)scale(0.8);"><input type="text" id="customPrefixInput"/></div><label>&nbsp;&nbsp;Prefix</label>';
    holderDiv.appendChild(prefix);

    var suffix = document.createElement('div');
    suffix.id = "suffixDiv";
    suffix.innerHTML = '<div id="customSuffixDivWrapper" style="position:absolute;left:50%; -webkit-transform:translate(-50%,0%)scale(0.8);"><input type="text" id="customSuffixInput"/></div><label>&nbsp;&nbsp;Suffix</label>';
    holderDiv.appendChild(suffix);

    action.cgAffix('prefix');
    action.cgAffix('suffix');
};

menu.insertCustomCSS = function(){
    var textArea = document.getElementById('customCSSText'),
    cssName, cssValue;
    textArea.innerHTML = "";
    Object.keys(action.savedElements.placedElements[action.selectedItem]).forEach(function (key) {
        cssName = key,
        cssValue = action.savedElements.placedElements[action.selectedItem][key];
        textArea.innerHTML += cssName + ":" + cssValue + '; '
    });
    textArea.value = textArea.innerHTML;
};

//example
//background: linear-gradient(to right, #1e5799 0%,#2989d8 50%,#207cca 51%,#7db9e8 100%);
//background: -webkit-linear-gradient(-45deg, #1e5799 0%,#828419 50%,#dd2323 57%,#ef81df 100%);
//background: -webkit-radial-gradient(center, ellipse cover, #1e5799 0%,#828419 50%,#dd2323 57%,#ef81df 100%);
//background: -webkit-linear-gradient(left, #1e5799 0%,#828419 50%,#dd2323 57%,#ef81df 100%);
//background: -webkit-linear-gradient(top, #1e5799 0%,#828419 50%,#dd2323 57%,#ef81df 100%);
menu.convertLinearGradient = function (cssVal) {
    console.log(cssVal);
    var newStart = "";
        var splitto = cssVal.split(',');
        if (cssVal.indexOf("to") != -1) {
            if(Number(cssVal.indexOf("top")) >= 1){
                newStart += splitto[0] + ", ";
            }else{
                newStart += splitto[0].replace('to', 'to ') + ", ";
            }
        }
        if (cssVal.indexOf("deg") != -1) {
            newStart += splitto[0] + ", ";
        }
        if (cssVal.indexOf("center") != -1) {
            newStart += splitto[0] + ", ";
        }
        if (cssVal.indexOf("left") != -1){
            newStart += splitto[0] + ", ";
        }
        for (var f = 1; f < splitto.length; f++) {
            var part = splitto[f].replace(')', '');
                newStart += " " + part.substr(0, 7) + " " + part.substr(7, 9);
            if (f === splitto.length - 1) {
                newStart += ")";
            } else {
                newStart += ",";
            }
        }
        cssVal = newStart;
    return newStart;
};
menu.updateCustomCSS = function() {
    var textArea = document.getElementById('customCSSText'),
        inner = textArea.value.replace(/\s/g, ""),
        ar = inner.split(';'),
        i, //loop one
        splt,
        multiplePX,
        e, //loop 2
        findzero,
        cssName,
        cssVal;
    for (i = 0; i < ar.length; i++) {
        splt = ar[i].split(':');
        cssName = splt[0];
        cssVal = splt[1];
        if (cssName && cssVal) {
            if ($('#' + action.selectedItem).css(cssName) != cssVal) {
                multiplePX = cssVal.split('px'); //if string contains multiple px it needs spacing
                if (multiplePX.length > 1) {
                    cssVal = ""; //clear cssVal as we will make it ourself
                    for (e = 0; e < multiplePX.length - 1; e++) {
                        findzero = multiplePX[e].split('0');
                        if (findzero.length > 1) { //if there is a split meaning another char other than 0
                            if (!findzero[0].indexOf('px') !== -1) { //if there isn't px on first split[0]
                                if (findzero[1].length == 1 && findzero[1] != ",") { //if next split contains 1 char and there isn't a comma after
                                    multiplePX[e] = "0 " + findzero[1]; //zero with a space and add rest
                                }
                            }
                        }
                        cssVal += multiplePX[e] + "px "; //set cssval to our made string
                    };
                    cssVal += multiplePX[multiplePX.length - 1]; //add last element
                }
                //if linear gradient
                if (cssVal.indexOf("gradient") !=-1) {
                    cssVal = menu.convertLinearGradient(cssVal);
                }
            
                if(cssName === 'innerHTML'){
                    //do nothing
                }else{
                    
                    $('#' + action.selectedItem).css(cssName, cssVal);
                    action.savedElements.placedElements[action.selectedItem][cssName] = cssVal;
                }
            }
        }
    };
    action.saveStorage();
    textArea.value = "";
    textArea.innerHTML = "";
};

menu.createCustomCSS = function(id, liName){
    var customCSS, label, cCSS, holderDiv;
    customCSS = document.createElement('li');
    customCSS.id = "BMcustomCSS";
    customCSS.className = "bottomMenuLI";
    document.getElementById('bottomMenuUL').appendChild(customCSS);

    label = document.createElement('div');
    label.innerHTML = "Custom CSS";
    label.className = "liText";
    customCSS.appendChild(label);

    holderDiv = document.createElement('div');
    holderDiv.style.cssText = "width:100%; position:absolute; top:50%; -webkit-transform:translate(0%,-50%)";
    customCSS.appendChild(holderDiv);

    cCSS = document.createElement('textarea');
    cCSS.className = "customCSSInput";
    cCSS.id = "customCSSText";
    cCSS.cols = "40";
    holderDiv.appendChild(cCSS);

    $('#customCSSText').focus(function() {
            menu.insertCustomCSS();
        }).blur(function() {
            menu.updateCustomCSS();
        });
};

menu.createWhat = function (liName, does, id) {
    switch (liName) {
    case 'Rotate':
    case 'triRotate':
    case 'triSize':
    case 'zindex':
    case 'size':
    case 'width':
        menu.createRange(id, does);
        break;
    case 'addtext':
        menu.createButtons(id, liName);
        break;
    case 'adddiv':
        menu.createButtons(id, liName);
        break;
    case 'height':
        menu.createRange(id, does);
        break;
    case 'radius':
        menu.createRange(id, does);
        break;
    case 'iconsize':
        menu.createRange(id, does);
        break;
    case 'widgetsize':
        menu.createRange(id, does);
        break;
    case 'position':
        menu.createPositionInputs(id, does);
        break;
    case 'triColor':
    case 'boxColor':
    case 'color':
        menu.createButtons(id, liName);
        break;
    case 'textGradient':
        menu.createButtons(id, liName);
        break;
    case 'changeicon':
        menu.createButtons(id, liName);
        break;
    case 'center':
        menu.createButtons(id, liName);
        break;
    case 'Battery':
        menu.createButtons(id, liName);
        break;
    case 'fonts':
        menu.createButtons(id, liName);
        break;
    case 'shadow':
        menu.createButtons(id, liName);
        break;
    case 'copyStyle':
        menu.createButtons(id, liName);
        break;
    case 'align':
        menu.createTriButtons(id, 'left', 'center', 'right');
        break;
    case 'animations':
        menu.createButtons(id, liName);
        break;
    case 'vertical':
        menu.createTriButtons(id, 'normal', 'verticalR', 'verticalL');
        break;
    case 'disabled':
        menu.createButtons(id, liName);
        break;
    case 'delete':
        menu.createButtons(id, liName);
        break;
    case 'uppercase':
        menu.createTriButtons(id, 'Upper', 'Cap', 'Lower');
        break;
    case 'style':
        menu.createTriButtons(id, 'Italic', 'Oblique', 'Initial');
        break;
    case 'border':
        menu.createBorderButton(id);
        break;
    case 'textborder':
        menu.createBorderButton(id);
        break;
    case 'weight':
        menu.createTriButtons(id, '100', 'Bold', 'Normal');
        break;
    case 'blurbehind':
        menu.createTriButtons(id, '5px', '10px', 'None');
        break;
    case 'fade':
        menu.createTriButtons(id, 'Top', 'Bottom', 'None');
        break;
    case 'decoration':
        menu.createTriButtons(id, 'Underline', 'Strike', 'None');
        break;
    case 'spacing':
        menu.createTriButtons(id, '2px', '5px', 'None');
        break;
    case 'boxShadow':
        menu.createButtons(id, liName);
        break;
    default:
        'null';
    }
};

menu.createList = function (liName, does) {
    var UL = document.getElementById('bottomMenuUL');
    var li = document.createElement('li');
    var div = document.createElement('div');
    if(liName === "align"){
        div.innerHTML = "align - based on element width";
    }else if(liName === "weight"){
        div.innerHTML = "weight - if font supports it";
    }else if(liName === "blurbehind"){
        div.innerHTML = "blur - blur behind object";
    }else if(liName === "fade"){
        div.innerHTML = "fade - animation";
    }else if (liName === "textborer"){
        div.innerHTML = "text border";
    }else if (liName === "Battery"){
        div.innerHTML = "Use as battery";
    }else{
        div.innerHTML = liName;
    }
    div.className = 'liText';
    li.id = 'BM' + liName;
    li.className = 'bottomMenuLI';
    li.appendChild(div);
    UL.appendChild(li);
    menu.createWhat(liName, does, li.id);
};

menu.createEdits = function () {
    var names;


    if (action.selectedItem.substring(0, 3) === 'box') {
        for (var i = 0; i < constants.boxEditArray.length; i++) {
            names = constants.boxEditArray[i].split('~')[0];
            if ( names === 'transform' || names === 'linearBoxGradient') { //temp disable
                //do nothing
            }else if(names === 'customCSS'){
                menu.createCustomCSS(constants.editArray[i].split('~')[0], constants.editArray[i].split('~')[4]);
            }else {
                menu.createList(constants.boxEditArray[i].split('~')[0], constants.boxEditArray[i].split('~')[4]);
            }
        };
    }else if (action.selectedItem.substring(0, 3) === 'tri') {
        for (var i = 0; i < constants.triEditArray.length; i++) {
            names = constants.triEditArray[i].split('~')[0];
            if (names === 'boxShadow' || names === 'transform' || names === 'linearBoxGradient') { //temp disable
                //do nothing
            }else if(names === 'customCSS'){
                menu.createCustomCSS(constants.editArray[i].split('~')[0], constants.editArray[i].split('~')[4]);
            } else {
                menu.createList(constants.triEditArray[i].split('~')[0], constants.triEditArray[i].split('~')[4]);
            }
        };
    }else if (action.selectedItem == 'songalbumArt') {
        for (var i = 0; i < constants.boxEditArray.length; i++) {
            names = constants.boxEditArray[i].split('~')[0];
            if ( names === 'transform' || names === 'linearBoxGradient' || names === 'boxColor' || names === 'boxShadow' || names === 'blurbehind') { //temp disable
                //do nothing
            }else if(names === 'customCSS'){
                menu.createCustomCSS(constants.editArray[i].split('~')[0], constants.editArray[i].split('~')[4]);
            } else {
                menu.createList(constants.boxEditArray[i].split('~')[0], constants.boxEditArray[i].split('~')[4]);
            }
        }
    } else if ($.inArray(action.selectedItem, widgetArray) != -1) { //widget bruh

        for (var i = 0; i < constants.widgetArray.length; i++) {
            names = constants.widgetArray[i].split('~')[0];
            if (names === 'transform') {

            }else if(names === 'customCSS'){
                menu.createCustomCSS(constants.editArray[i].split('~')[0], constants.editArray[i].split('~')[4]);
            } else {
                menu.createList(constants.widgetArray[i].split('~')[0], constants.widgetArray[i].split('~')[4]);
            }
        }

    } else if (action.selectedItem === 'icon' || action.selectedItem === 'day1icon' || action.selectedItem === 'day2icon' || action.selectedItem === 'day3icon' || action.selectedItem === 'day4icon' || action.selectedItem === 'day5icon') {
        for (var i = 0; i < constants.iconArray.length; i++) {
            names = constants.iconArray[i].split('~')[0];
            if (names === 'transform') {

            }else if(names === 'customCSS'){
                menu.createCustomCSS(constants.editArray[i].split('~')[0], constants.editArray[i].split('~')[4]);
            } else {
                menu.createList(constants.iconArray[i].split('~')[0], constants.iconArray[i].split('~')[4]);
            }
        }
    } else if (action.selectedItem.length > 4 && action.selectedItem.substring(0,4) === 'text') {
        for (var i = 0; i < constants.customTextNew.length; i++) {
            names = constants.customTextNew[i].split('~')[0];
            if (names === 'transform') {

            }else if(names === 'customCSS'){
                menu.createCustomCSS(constants.editArray[i].split('~')[0], constants.editArray[i].split('~')[4]);
            } else {
                menu.createList(constants.customTextNew[i].split('~')[0], constants.customTextNew[i].split('~')[4]);
            }
        }
    }else if(action.selectedItem.substring(0,9) === 'customDiv'){
        for (var i = 0; i < constants.customDivArray.length; i++) {
            names = constants.customDivArray[i].split('~')[0];
            if (names === 'transform' || names === 'affixes' || names === 'linearGradient') { //tmp disable
                if(names === 'affixes'){
                    //menu.createList(constants.editArray[i].split('~')[0], constants.editArray[i].split('~')[4]);
                    menu.createAffixes(constants.customDivArray[i].split('~')[0], constants.customDivArray[i].split('~')[4]);
                }
            }else if(names === 'customCSS'){
                menu.createCustomCSS(constants.customDivArray[i].split('~')[0], constants.customDivArray[i].split('~')[4]);
            } else {
                menu.createList(constants.customDivArray[i].split('~')[0], constants.customDivArray[i].split('~')[4]);
            }
        }
    } else {
        for (var i = 0; i < constants.editArray.length; i++) {
            names = constants.editArray[i].split('~')[0];
            if (names === 'transform' || names === 'affixes' || names === 'linearGradient') { //tmp disable
                if(names === 'affixes'){
                    //menu.createList(constants.editArray[i].split('~')[0], constants.editArray[i].split('~')[4]);
                    menu.createAffixes(constants.editArray[i].split('~')[0], constants.editArray[i].split('~')[4]);
                }
            }else if(names === 'customCSS'){
                menu.createCustomCSS(constants.editArray[i].split('~')[0], constants.editArray[i].split('~')[4]);
            } else {
                menu.createList(constants.editArray[i].split('~')[0], constants.editArray[i].split('~')[4]);
            }
        }
    }
};

menu.bottomMenuActions = {
    createDiv: function(div){
        var el = document.createElement(div.type);
            el.id = div.id;
            el.className = div.class;
            el.innerHTML = div.html;
            div.container.appendChild(el);
            return el;
    },
    upsizeMenuToggle: function(menu, dragger, button){
        var defaults = {
            // styles are set in menu.css
            menuHeight: '200px',
            draggerBottom: '253px',
            draggerOpacity: '1',
            arrowType: '&uarr;'
        };
        if(menu.style.height != '85%'){
            defaults.menuHeight = '85%';
            defaults.draggerOpacity = '0';
            defaults.arrowType = '&darr;';
        }
        menu.style.height = defaults.menuHeight;
        dragger.style.bottom = defaults.draggerBottom;
        dragger.style.opacity = defaults.draggerOpacity;
        button.innerHTML = defaults.arrowType;
        // remove top value just incase dragger moved it
        menu.style.top = 'auto';
        // need to clear dragger top to set back to default
        dragger.style.top = null;
    },
    createEditMenu: function(){

    }
};

/* 
    BottomMenu aka Element style menu
    : is opened when an element on the screen is selected
    : is closed when screen is tapped
    : contains an object which drags it, maximizes it, and an inner UL. 
*/

menu.bottomMenu = function () {

    var mainMenu, dragger, upsize, mainMenuUL, bottomMenu;
    mainMenu = menu.bottomMenuActions.createDiv({
        type: 'div',
        id: 'bottomMenu',
        html: '',
        class: action.selectedItem + "Menu",
        container: document.body
    });
    dragger = menu.bottomMenuActions.createDiv({
        type: 'div',
        id: 'editDragger',
        html: 'DragMe!',
        class: '',
        container: document.body
    });
    mainMenuUL = menu.bottomMenuActions.createDiv({
        type: 'ul',
        id: 'bottomMenuUL',
        html: '',
        class: '',
        container: mainMenu
    });
    upsize = menu.bottomMenuActions.createDiv({
        type: 'div',
        id: '',
        html: '&uarr;',
        class: 'upsizer',
        container: mainMenu
    });

    //add events
    upsize.onclick = function(){
        menu.bottomMenuActions.upsizeMenuToggle(mainMenu, dragger, this);
    };
    mainMenu.ontouchmove = function(){
        action.isScrollingEdit = true;
    };
    mainMenu.ontouchend = function(){
        action.isScrollingEdit = false;
    };

    //allow dragging
    $(dragger).draggable({
        axis: "y",
        drag: function (event, ui) {
            if (ui.position.top > screen.height - mainMenu.style.height) {
                ui.position.top = screen.height - mainMenu.style.height;
            } else if (ui.position.top < 0) {
                ui.position.top = 0;
            }
            //need to get the actual menu
            document.getElementById('bottomMenu').style.top = ui.position.top + 10;
        }
    });

    //need this in case another element is selected it moves the menu to it.
    $('#bottomMenu').css('top', $('#editDragger').css('top'));
    //$("#bottomMenu").draggable({ axis: "y", scroll: true });

    //setup menu content for UL
    this.createEdits();
};

menu.init = function () {
    this.button();
};

function showElementPanel() {
    $('.sidePanel').css('opacity', '0');
}

menu.init();
