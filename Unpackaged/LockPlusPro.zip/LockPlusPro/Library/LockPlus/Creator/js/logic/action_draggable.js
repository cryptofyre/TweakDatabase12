/*jslint
  node: true,
  sloppy: true,
  browser: true,
  todo: true,
  unparam: true
*/
/*global
  action,
  alert,
  handleScreenClick,
  constants,
  $
*/
/**
 * Draggable options for every element
 *
 *
 */

action.syncInputs = function (left, top) {
    try {
        var t = document.querySelector('.topInput'),
            l = document.querySelector('.leftInput');
        if(t){ //item may be dragged but not selected
            t.value = Math.round(top);
            l.value = Math.round(left);
        }
    } catch (err) {
        console.log(err);
    }
};

action.addDraggable = function (id) {
    var contain,
        iswidget;

    if ($.inArray(id, widgetArray) != -1) {
      iswidget = true;
    }

    if (id === 'icon' || iswidget === true || id.substring(0, 3) === 'tri') {
        contain = '';
    } else {
        //contain = $('.screen');
        contain = '';
    }
    /*var startX;
    var startY;*/

    $('#' + id).draggable({
        containment: contain,
        start: function (event, ui) {
            /* if dLine class has title the same as id remove it */
            /* remove it on start to not mess with it's own movement */
            /* it will snap to itself this solves that issue */
            $(".dLine[title='" + id + "']").remove();
            if (action.selectedItem !== id) {
                handleScreenClick(event);
            }

            action.sizeQueueTimeout.initialValue = [$('#' + id).position().top, $('#' + id).position().left]; //Just borrowing it, nothing else will need this while you're moving an element
        },
        stop: function (event, ui) {
            var position = $('#' + id).position(),
                snapper,
                el;
            action.addAction(['setCss', [
                [id, ['top', 'left'], action.sizeQueueTimeout.initialValue, [position.top, position.left]]
            ]]);
            action.sizeQueueTimeout.initialValue = '';

            // Since we're not going through setCss, it's never saved to localStorage. Gotta do it manually

            action.syncInputs(position.left, position.top);


            action.savedElements.placedElements[id].left = position.left;
            action.savedElements.placedElements[id].top = position.top;
            action.saveStorage();

            /* So a random bug popped up, when an item is dragged it sets a height. WHY?
               Which means if you resize the font the bounding box didn't change. This fixes that.
             */
            if ($.inArray(id, widgetArray) != -1) { //fix for widgets not wanting to get right
              action.savedElements.placedElements[id].left = ui.position.left;
              action.savedElements.placedElements[id].top = ui.position.top;
              action.saveStorage();
            }
            if (id.substring(0, 3) !== 'box' && id !== 'songalbumArt' && id !== 'songalbumArtnohide' && id.substring(3, 9) !== 'Circle' && $.inArray(id, widgetArray) == -1) { //don't change box //don't change circle
                $('#' + id).css('height', 'auto');
            }

            /* Create a div around the element which can be used for snapping */
            if (localStorage.snap === 'true') {
                snapper = $('<div>', {
                    'class': 'dLine',
                    'title': id
                });
                el = $('#' + id);
                position = el.position();
                snapper.insertBefore(el);
                snapper.css({
                    top: position.top + 'px',
                    left: position.left + 'px',
                    width: el.width(),
                    height: el.height()
                });
            }
        },
        snap: '.dLine' //snap other items to that div.
    });
};
