
var constants = {
    //left panel array format: li.id~title~li.class the optionally ~divId if surroundingDiv is true
    notSoConstantArray: [],
    toolArray: ['background~Background~fa fa-photo~backgroundDiv~Background'
                    ,'overlay~Overlay~fa fa-clipboard~overlayDiv~Overlay'
                    ,'element~Show Elements Panel~fa fa-flask~elementDiv~Elements'
                    ,'elements~Placed Elements~fa fa-upload~elementsPlaced~Placed Items'
                    ,'widget~Load Widget~fa fa-flag~loadWidget~Widgets'
                    ,'fontadd~Save Theme~fa fa-upload~fontAddDiv~Add Font'
                    ,'moveall~Move Items~fa fa-upload~fontAddDiv~Move All'
                    ,'save~Save Theme~fa fa-upload~saveDiv~Upload'
                    ,'clear~Clear Theme~fa fa-eraser~clearDiv~Clear'
                    ,'exit~Exit~fa fa-check~moreDiv~Exit/Apply'],
    backgroundArray: ['cgBackground~Change Background~fa fa-photo~cgBackgroundDiv~Camera Roll'
                     /*,'openBackground~View Background in New Tab~fa fa-external-link-square~openBackgroundDiv'*/
                     //,'backgroundBlur~Change Background Blur~fa fa-bullseye~backgroundBlurDiv~BlurBG'
                    /* ,'openBlurryBackground~View Blurred Background in New Tab~fa fa-external-link~openBlurryBackgroundDiv'*/
                     ,'viewBackground~Download~fa fa-trash~clearBackgroundDiv~Download'
                     ,'clearBackground~Clear Background~fa fa-trash~clearBackgroundDiv~Clear'
                     ,'backToTools~Back~fa fa-arrow-left~backToToolsDiv~Back'
                     ],
    overlayArray: ['cgOverlay~Change Overlay~fa fa-clipboard~null~Choose'
                    ,'viewOverlays~Download~null~null~Download'
                    ,'clearOverlay~Clear Overlay~fa fa-trash~null~Remove'
                    ,'backToTools~Back~fa fa-arrow-left~null~Back'],
    editArray: ['size~Change Font Size~fa fa-font~sizeDiv~font-size'
                    ,'position~Change Position~fa fa-arrows~positionDiv~top-left'
                    ,'width~Change Width~fa fa-arrows-h~widthDiv~width'
                    ,'height~Change Height~fa fa-arrows-v~heightDiv~height'
                    ,'Rotate~Change Height~fa fa-arrows-v~RotateDiv~Rotate'
                    ,'zindex~Edit Box Border~fa fa-square-o~zindexDiv~blur'
                    ,'color~Change Color~fa fa-eyedropper~colorDiv' //added
                    ,'textGradient~Change Color~fa fa-eyedropper~textGradient'
                    ,'copyStyle~CopyStyle!fa fa-eyedropper~copyStyle' //added
                    //,'fade~Change Font Weight~fa fa-text-width~fadeDiv' //added
                    ,'align~Change Alignment~fa fa-align-center~alignDiv'
                    ,'vertical~Change Vertical~fa fa-align-center~verticalDiv'
                    ,'fonts~Change Font~ fa fa-language~fontsDiv'
                    ,'weight~Change Font Weight~fa fa-text-width~weightDiv' //added
                    ,'spacing~Change Font Weight~fa fa-text-width~spacingDiv' //added
                    ,'decoration~Change Font Weight~fa fa-text-width~decorationDiv' //added
                    ,'transform~Change Transformations~fa fa-level-up~transformDiv'
                    ,'uppercase~Change Uppercase~fa fa-text-height~uppercaseDiv' //added
                    ,'style~Change Font Style~fa fa-italic~styleDiv'
                    ,'textborder~Edit Box Border~fa fa-square-o~borderDiv~textborder'
                    ,'affixes~Change Prefix/Suffix~fa fa-edit~affixesDiv'
                    ,'shadow~Edit Text Shadow~fa fa-underline~shadowDiv'
                    ,'linearGradient~Edit Linear Text Color Gradient~fa fa-barcode~linearTextGradientDiv'
                    ,'customCSS~Edit Linear Text Color Gradient~fa fa-barcode~customCSSDiv'
                    ,'disabled~Edit Text Shadow~fa fa-underline~disabledDiv'
                    ,'animations~Edit Text Shadow~fa fa-underline~animations'
                    ,'adddiv~Change text~fa fa-text-width~addtextDiv' //added
                    ,'delete~Delete item~fa fa-trash-o~deleteDiv'],
    customDivArray: ['size~Change Font Size~fa fa-font~sizeDiv~font-size'
                    ,'position~Change Position~fa fa-arrows~positionDiv~top-left'
                    ,'width~Change Width~fa fa-arrows-h~widthDiv~width'
                    ,'height~Change Height~fa fa-arrows-v~heightDiv~height'
                    ,'Rotate~Change Height~fa fa-arrows-v~RotateDiv~Rotate'
                    //,'color~Change Color~fa fa-eyedropper~colorDiv' //added
                    //,'fade~Change Font Weight~fa fa-text-width~fadeDiv' //added
                    ,'align~Change Alignment~fa fa-align-center~alignDiv'
                    ,'vertical~Change Vertical~fa fa-align-center~verticalDiv'
                    ,'fonts~Change Font~ fa fa-language~fontsDiv'
                    ,'weight~Change Font Weight~fa fa-text-width~weightDiv' //added
                    ,'spacing~Change Font Weight~fa fa-text-width~spacingDiv' //added
                    //,'decoration~Change Font Weight~fa fa-text-width~decorationDiv' //added
                    ,'transform~Change Transformations~fa fa-level-up~transformDiv'
                    ,'uppercase~Change Uppercase~fa fa-text-height~uppercaseDiv' //added
                    ,'style~Change Font Style~fa fa-italic~styleDiv'
                    //,'textborder~Edit Box Border~fa fa-square-o~borderDiv~textborder'
                    //,'affixes~Change Prefix/Suffix~fa fa-edit~affixesDiv'
                    //,'shadow~Edit Text Shadow~fa fa-underline~shadowDiv'
                    ,'linearGradient~Edit Linear Text Color Gradient~fa fa-barcode~linearTextGradientDiv'
                    //,'customCSS~Edit Linear Text Color Gradient~fa fa-barcode~customCSSDiv'
                    ,'disabled~Edit Text Shadow~fa fa-underline~disabledDiv'
                    ,'animations~Edit Text Shadow~fa fa-underline~animations'
                    ,'adddiv~Change text~fa fa-text-width~addtextDiv' //added
                    ,'delete~Delete item~fa fa-trash-o~deleteDiv'],
                    customTextNew: ['size~Change Font Size~fa fa-font~sizeDiv~font-size'
                                    ,'width~Change Width~fa fa-arrows-h~widthDiv~width'
                                    ,'position~Change Position~fa fa-arrows~positionDiv~top-left'
                                    ,'zindex~Edit Box Border~fa fa-square-o~zindexDiv~blur'
                                    ,'color~Change Color~fa fa-eyedropper~colorDiv' //added
                                    ,'copyStyle~CopyStyle!fa fa-eyedropper~copyStyle' //added
                                    ,'vertical~Change Vertical~fa fa-align-center~verticalDiv'
                                    //,'fade~Change Font Weight~fa fa-text-width~fadeDiv' //added
                                    ,'align~Change Alignment~fa fa-align-center~alignDiv'
                                    ,'fonts~Change Font~ fa fa-language~fontsDiv'
                                    ,'weight~Change Font Weight~fa fa-text-width~weightDiv' //added
                                    ,'spacing~Change Font Weight~fa fa-text-width~spacingDiv' //added
                                    ,'decoration~Change Font Weight~fa fa-text-width~decorationDiv' //added
                                    ,'transform~Change Transformations~fa fa-level-up~transformDiv'
                                    ,'uppercase~Change Uppercase~fa fa-text-height~uppercaseDiv' //added
                                    ,'style~Change Font Style~fa fa-italic~styleDiv'
                                    ,'textborder~Edit Box Border~fa fa-square-o~borderDiv~textborder'
                                    ,'shadow~Edit Text Shadow~fa fa-underline~shadowDiv'
                                    ,'addtext~Change text~fa fa-text-width~addtextDiv' //added
                                    ,'customCSS~Edit Linear Text Color Gradient~fa fa-barcode~customCSSDiv'
                                    ,'disabled~Edit Text Shadow~fa fa-underline~disabledDiv'
                                    ,'animations~Edit Text Shadow~fa fa-underline~animations'
                                    ,'adddiv~Change text~fa fa-text-width~addtextDiv' //added
                                    ,'delete~Delete item~fa fa-trash-o~deleteDiv'],
    customTextArray: ['customText~Change Text~fa fa-pencil~textDiv'
                    ,'size~Change Font Size~fa fa-font~sizeDiv'
                    ,'width~Change Width~fa fa-arrows-h~widthDiv'
                    ,'position~Change Position~fa fa-arrows~positionDiv'
                    ,'color~Change Color~fa fa-eyedropper~colorDiv' //added
                    ,'copyStyle~CopyStyle!fa fa-eyedropper~copyStyle' //added
                    ,'textGradient~Change Color~fa fa-eyedropper~textGradient' //added
                    ,'align~Change Alignment~fa fa-align-center~alignDiv'
                    ,'fonts~Change Font~ fa fa-language~fontsDiv'
                    ,'transform~Change Transformations~fa fa-level-up~transformDiv'
                    ,'uppercase~Change Uppercase~fa fa-text-height~uppercaseDiv' //added
                    ,'weight~Change Font Weight~fa fa-text-width~weightDiv' //added
                    ,'style~Change Font Style~fa fa-italic~styleDiv'
                    ,'shadow~Edit Text Shadow~fa fa-underline~shadowDiv'
                    ,'linearGradient~Edit Linear Text Color Gradient~fa fa-barcode~linearTextGradientDiv'
                    ,'disabled~Edit Text Shadow~fa fa-underline~disabledDiv'
                    ,'delete~Delete item~fa fa-trash-o~deleteDiv'],

    affixArray: ['customPrefix~Change Prefix~fa fa-long-arrow-left~prefixDiv'
                    ,'customSuffix~Change Suffix~fa fa-long-arrow-right~suffixDiv'
                    ,'backToEdit~Back~fa fa-arrow-left~backToEditDiv'
                    ,'clearAffixes~Clear Prefix and Suffix~fa fa-trash~clearAffixesDiv'],
    shadowArray: ['hShadow~Horizontal~fa fa-arrows-h~hShadowDiv'
                    ,'vShadow~Vertical~fa fa-arrows-v~vShadowDiv'
                    ,'blur~Blur Radius~fa fa-dot-circle-o~blurDiv'
                    ,'shadowColor~Change Color~fa fa-eyedropper~shadowColorDiv'
                    ,'backToEdit~Back~fa fa-arrow-left~backToEditDiv'
                    ,'clearShadow~Clear Shadow~fa fa-trash~clearShadowDiv'],
    boxShadowArray: ['boxhShadow~Horizontal~fa fa-arrows-h~boxhShadowDiv'
                    ,'boxvShadow~Vertical~fa fa-arrows-v~boxvShadowDiv'
                    ,'boxblur~Blur Radius~fa fa-dot-circle-o~boxblurDiv'
                    ,'boxshadowColor~Change Color~fa fa-eyedropper~boxshadowColorDiv'
                    ,'backToEdit~Back~fa fa-arrow-left~backToEditDiv'
                    ,'boxclearShadow~Clear Shadow~fa fa-trash~boxclearShadowDiv'],
    transformArray: ['rotation~Change Rotation Angle~fa fa-repeat~rotationDiv'
                    ,'skewX~Change X Skew~fa fa-text-width~skewXDiv'
                    ,'skewY~Change Y Skew~fa fa-text-height~skewYDiv'
                    ,'backToEdit~Back~fa fa-arrow-left~backToEditDiv'
                    ,'clearTransform~Clear Transformations~fa fa-trash~clearTransformsDiv'],
    linearGradientArray: ['gradientType~Gradient Type~fa fa-square~gradientTypeDiv'
                    ,'linearGradientAngle~Change Gradient Angle~fa fa-repeat~linearGradientAngleDiv'
                    ,'linearGradientStartColor~Change Start Color~fa fa-eyedropper~linearGradientStartColorDiv'
                    ,'linearGradientStopColorOne~Change Color Stop 1~fa fa-eyedropper~linearGradientStopColorOneDiv'
                    ,'linearGradientStopColorTwo~Change Color Stop 2~fa fa-eyedropper~linearGradientStopColorTwoDiv'
                    ,'backToEdit~Back~fa fa-arrow-left~backToEditDiv'
                    ,'clearGradient~Clear Gradient~fa fa-trash~clearGradientDiv'],
    linearBoxGradientArray: ['linearGradientAngle~Change Gradient Angle~fa fa-repeat~linearGradientAngleDiv'
                    ,'linearGradientStartColor~Change Start Color~fa fa-eyedropper~linearGradientStartColorDiv'
                    ,'linearGradientStopColorOne~Change Color Stop 1~fa fa-eyedropper~linearGradientStopColorOneDiv'
                    ,'linearGradientStopColorTwo~Change Color Stop 2~fa fa-eyedropper~linearGradientStopColorTwoDiv'
                    ,'backToEdit~Back~fa fa-arrow-left~backToEditDiv'
                    ,'clearGradient~Clear Gradient~fa fa-trash~clearGradientDiv'],
    boxEditArray: ['boxColor~Change Color~fa fa-eyedropper~boxColorDiv~color'
                    ,'center~Change Color~fa fa-eyedropper~centerDiv'
                    ,'position~Change Position~fa fa-arrows~positionDiv~top-left'
                    ,'width~Change Width~fa fa-arrows-h~widthDiv~width'
                    ,'height~Change Height~fa fa-arrows-v~heightDiv~height'
                    ,'copyStyle~CopyStyle!fa fa-eyedropper~copyStyle' //added
                    ,'radius~Change Radius~fa fa-circle~radiusDiv~border-radius'
                    ,'Rotate~Change Height~fa fa-arrows-v~RotateDiv~Rotate'
                    ,'Battery~Use as battery~fa fa-arrows-v~RotateDiv~Battery'
                    ,'boxShadow~Edit Box Shadow~fa fa-cube~boxShadowDiv~box-shadow'
                    ,'transform~Change Transformations~fa fa-level-up~transformDiv~transform'
                    ,'border~Edit Box Border~fa fa-square-o~borderDiv~border'
                    ,'blurbehind~Edit Box Border~fa fa-square-o~borderDiv~blur'
                    ,'zindex~Edit Box Border~fa fa-square-o~zindexDiv~blur'
                    ,'customCSS~Edit Linear Text Color Gradient~fa fa-barcode~customCSSDiv'
                    ,'linearBoxGradient~Edit Linear Box Color Gradient~fa fa-barcode~linearTextGradientDiv~shadow'
                    ,'disabled~Edit Text Shadow~fa fa-underline~disabledDiv'
                    ,'animations~Edit Text Shadow~fa fa-underline~animations'
                    ,'delete~Delete item~fa fa-trash-o~deleteDiv~delete'],
    circleEditArray: ['boxColor~Change Color~fa fa-eyedropper~boxColorDiv'
                    ,'center~Change Color~fa fa-eyedropper~centerDiv'
                    ,'position~Change Position~fa fa-arrows~positionDiv'
                    ,'width~Change Width~fa fa-arrows-h~widthDiv'
                    ,'copyStyle~CopyStyle!fa fa-eyedropper~copyStyle' //added
                    ,'boxShadow~Edit Circle Shadow~fa fa-cube~boxShadowDiv'
                    ,'transform~Change Transformations~fa fa-level-up~transformDiv'
                    ,'border~Edit Box Border~fa fa-square-o~borderDiv'
                    ,'Rotate~Change Height~fa fa-arrows-v~RotateDiv~Rotate'
                    ,'blurbehind~Edit Box Border~fa fa-square-o~borderDiv~blur'
                    ,'zindex~Edit Box Border~fa fa-square-o~zindexDiv~blur'
                    ,'customCSS~Edit Linear Text Color Gradient~fa fa-barcode~customCSSDiv'
                    ,'linearBoxGradient~Edit Linear Box Color Gradient~fa fa-barcode~linearTextGradientDiv'
                    ,'disabled~Edit Text Shadow~fa fa-underline~disabledDiv'
                    ,'animations~Edit Text Shadow~fa fa-underline~animations'
                    ,'delete~Delete item~fa fa-trash-o~deleteDiv'],
    triEditArray: ['triColor~Change Color~fa fa-eyedropper~triColorDiv~color'
                    ,'center~Change Color~fa fa-eyedropper~centerDiv'
                    ,'position~Change Position~fa fa-arrows~positionDiv~top-left'
                    ,'width~Change Width~fa fa-arrows-h~widthDiv~width'
                    ,'height~Change Height~fa fa-arrows-v~heightDiv~height'
                    ,'triSize~Change Width~fa fa-arrows-h~triSizeDiv~width'
                    ,'triRotate~Change Width~fa fa-arrows-h~triRotateDiv~width'
                    ,'blurbehind~Edit Box Border~fa fa-square-o~borderDiv~blur'
                    ,'zindex~Edit Box Border~fa fa-square-o~zindexDiv~blur'
                    ,'customCSS~Edit Linear Text Color Gradient~fa fa-barcode~customCSSDiv'
                    ,'disabled~Edit Text Shadow~fa fa-underline~disabledDiv'
                    ,'animations~Edit Text Shadow~fa fa-underline~animations'
                    ,'delete~Delete item~fa fa-trash-o~deleteDiv~delete'],
    borderArray: ['borderStyle~Border Style~fa fa-ellipsis-v~borderStyleDiv'
                    ,'borderWidth~Border Width~fa fa-arrows-h~borderWidthDiv'
                    ,'border-color~Border Color~fa fa-eyedropper~border-colorDiv'
                    ,'backToEdit~Back~fa fa-arrow-left'
                    ,'clearBorder~Clear Border~fa fa-trash'],
    iconArray: ['iconsize~Change Icon Size~fa fa-expand~changeIconDiv~width'
                ,'position~Change Position~fa fa-arrows~positionDiv~top-left'
                , 'changeicon~Change Icon~fa fa-code-fork~changeIconDiv~change'
                ,'transform~Change Transformations~fa fa-level-up~transformDiv~transform'
                ,'customCSS~Edit Linear Text Color Gradient~fa fa-barcode~customCSSDiv'
                ,'disabled~Edit Text Shadow~fa fa-underline~disabledDiv'
                ,'animations~Edit Text Shadow~fa fa-underline~animations'
                ,'zindex~Edit Box Border~fa fa-square-o~zindexDiv~blur'
                , 'delete~Delete item~fa fa-trash-o~deleteDiv~delete'],
    widgetArray: ['widgetsize~Scale~fa fa-expand~changeWidgetDiv~width'
                ,'position~Change Position~fa fa-arrows~positionDiv~top-left'
                ,'customCSS~Edit Linear Text Color Gradient~fa fa-barcode~customCSSDiv'
                ,'disabled~Edit Text Shadow~fa fa-underline~disabledDiv'
                , 'delete~Delete item~fa fa-trash-o~deleteDiv~delete'],
                gridSizeTop: 160,
                gridSizeLeft: 284,
    //preloadBlacklist: {color:'', fonts:'',transform:'',shadow:'',linearGradient:'',linearBoxGradient:'',backToEdit:'',boxShadow:'',boxColor:'',changeicon:'',affixes:''}, /*//If it shouldn't be opened when the menu is opened, the id needs to be here. 'delete', 'clear', and 'color' are already taken care of*/
    preloadWhitelist: {'size':'','width':'', 'position':'','align':'','uppercase':'','weight':'','style':'','customPrefix':'','customSuffix':'','hShadow':'','vShadow':'','blur':'','boxhShadow':'','boxvShadow':''
                        ,'boxblur':'','rotation':'','skewX':'','skewY':'','gradientType':'','linearGradientAngle':'','height':'','radius':'','iconsize':'','customText':'','borderStyle':'','borderWidth':'', 'posSystem':'', 'multiPos':''},
    iconList: ['ambre2','ambre3','astral1','MonolyphDark','MonolyphFlat','MonolyphLight','city','blue', 'clima', 'deep', 'plex', 'Flex', 'GlowWhite', 'june', 'Klear', 'lines', 'mauri', 'mauri2', 'MNMLB', 'MNMLBW', 'MNMLW', 'mw', 'nude', 'plastic', 'playful', 'primusweather', 'Purcy', 'realicons', 'reddock', 'round', 'round2', 'shadow', 'shiny', 'simple', 'simply', 'six', 'sixtynine', 'Sk37ch', 'smash', 'stardock', 'swhite', 'toon', 'toon2', 'topaz', 'weathercom', 'wetter', 'yahoo','black', 'BlackOrange','blacky','bbl', 'blackd', 'cleard', 'flt', 'kelly', 'climacut', 'climablack', 'noidea', 'pbwidget', 'plaindark', 'plainwhite', 'htc', 'sticker', 'wth', 'yah1', 'yah2', 'yah3', 'custover', 'kuro', 'perfect', 'twofresh', 'faded'],
    positioningSystemOption : 'posSystem~Change Positioning System~fa fa-arrows-alt~posSystemDiv',
    multiPosition : 'multiPos~Change Position~fa fa-arrows~multiPosDiv'
};
